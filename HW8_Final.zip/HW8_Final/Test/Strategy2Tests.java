import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.AutoMoves;
import model.GoForCorners;
import model.TriosMove;
import model.Board;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.ModelMockTranscripted;
import model.TriosModel;

/**
 * tests for strategy 2.
 */
public class Strategy2Tests {

  private Board board3by3;
  private TriosModel modelToPass;
  private List<GameCard> deck = new ArrayList<>();
  private AutoMoves checkCorners;
  private Random randForShuffle;

  @Before
  public void setUp() throws FileNotFoundException {
    deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();

    Board board5by7 =
            new GridReader("ConfigurationFiles/basicGridConfigForTest").gridBuilder();
    board3by3 = new GridReader("ConfigurationFiles/3x3NoHoles").gridBuilder();
    randForShuffle = new Random(1);
    modelToPass = new TriosModel(board5by7, deck, randForShuffle);

    checkCorners = new GoForCorners();
  }

  /**
   * Tests Strategy2, the go for corners strategy on an empty 3 by 3 board.
   * Checks each corner 50 times, as our method uses the addIfFlipped() method,
   * Which checks each card in hand of current player against every card
   * in the other player's hand,
   * for the two spots that corner is exposed to.
   */
  @Test
  public void testStrategy2Checks4CornersEmpty3by3Board() {
    modelToPass = new TriosModel(board3by3, deck, randForShuffle);
    TriosMove move = checkCorners.chooseMove(modelToPass);
    ModelMockTranscripted mock = new ModelMockTranscripted(modelToPass);
    move = checkCorners.chooseMove(mock);
    List<GameCard> hand2 = mock.getHand(2);
    List<GameCard> hand1 = mock.getHand(1);
    Assert.assertEquals(hand2.get(0).getOwner(), 2);
    Assert.assertEquals(hand1.get(0).getOwner(), 1);
    Assert.assertEquals(move.toString(), "0,2,0");
    Assert.assertEquals(mock.listOfPlaced.toString(),
            "[00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "00, 00, 00, 00, 00, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "20, 20, 20, 20, 20, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22]");
  }

  /**
   * Tests Strategy2, the go for corners strategy on a non-empty 3 by 3 board.
   * In this case, corner 0,0 and 2,0 are taken already, and thus not checked.
   * Checks each corner 32 times, as our method uses the addIfFlipped() method,
   * Which checks each card in hand of current player against every card
   * in the other player's hand,
   * for the two spots that corner is exposed to.
   * since each player placed one card already, there are 4 cards in each.
   * 4 * 4 + 4 * 4 = 32 times checked.
   */
  @Test
  public void testStrategy2Checks4CornersTwoCornersTakenIn3by3Board() {
    modelToPass = new TriosModel(board3by3, deck, randForShuffle);
    modelToPass.placeCard(0, 0, 0);
    modelToPass.placeCard(2, 0, 0);
    TriosMove move = checkCorners.chooseMove(modelToPass);
    ModelMockTranscripted mock = new ModelMockTranscripted(modelToPass);
    move = checkCorners.chooseMove(mock);
    Assert.assertEquals(move.toString(), "0,2,2");
    Assert.assertEquals(mock.listOfPlaced.toString(),
            "[02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, 02, 02, 02, " +
                    "02, 02, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22]");
  }

  /**
   * Tests Strategy2, the go for corners strategy on a non-empty 3 by 3 board.
   * In this case, corner 0,0 & 2,0 & 0,2 are taken already, and thus not checked.
   * Checks the corner 24 times, as our method uses the addIfFlipped() method,
   * Which checks each card in hand of current player against every card
   * in the other player's hand,
   * for the two spots that corner is exposed to.
   * Since player1 placed 2 cards, and player2 placed 1 card, this checks the corner 24 timeS:
   * As 4 * 3 + 4 * 3 = 24.
   */
  @Test
  public void testStrategy2Checks4CornersThreeCornersTakenIn3by3Board() {
    modelToPass = new TriosModel(board3by3, deck, randForShuffle);
    modelToPass.placeCard(0, 0, 0);
    modelToPass.placeCard(2, 0, 0);
    modelToPass.placeCard(0, 2, 0);
    TriosMove move = checkCorners.chooseMove(modelToPass);
    ModelMockTranscripted mock = new ModelMockTranscripted(modelToPass);
    move = checkCorners.chooseMove(mock);
    Assert.assertEquals(move.toString(), "2,2,0");
    Assert.assertEquals(mock.listOfPlaced.toString(),
            "[22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22, 22, " +
                    "22, 22, 22, 22]");
  }

  /**
   * Tests Strategy2, the go for corners strategy on a non-empty 3 by 3 board.
   * In this case, all corners are taken and thus,
   * the best move is the most upperleft.
   * This also tests UpperLeftMove as it needs to find the upper-most left-most open spot.
   */
  @Test
  public void testStrategy2Checks4CornersAllCornersTaken() {
    modelToPass = new TriosModel(board3by3, deck, randForShuffle);
    modelToPass.placeCard(0, 0, 0);
    modelToPass.placeCard(2, 0, 0);
    modelToPass.placeCard(0, 2, 0);
    modelToPass.placeCard(2, 2, 0);
    TriosMove move = checkCorners.chooseMove(modelToPass);
    ModelMockTranscripted mock = new ModelMockTranscripted(modelToPass);
    move = checkCorners.chooseMove(mock);
    Assert.assertEquals(move.toString(), "0,1,0");
    Assert.assertEquals(mock.listOfPlaced.toString(),
            "[]");
  }

  /**
   * Tests Strategy2, the go for corners strategy on a non-empty 3 by 3 board.
   * In this case, all corners are taken and thus,
   * the best move is the most upperleft. However the most upperleft is also taken 0,1.
   * So it should go for 1,0 as thats the next best option.
   * This also tests UpperLeftMove as it needs to find the upper-most left-most open spot.
   */
  @Test
  public void testStrategy2Checks4CornersAllCornersTakenAndUpperLeftmostTaken() {
    modelToPass = new TriosModel(board3by3, deck, randForShuffle);
    modelToPass.placeCard(0, 0, 0);
    modelToPass.placeCard(2, 0, 0);
    modelToPass.placeCard(0, 2, 0);
    modelToPass.placeCard(2, 2, 0);
    modelToPass.placeCard(0, 1, 0);
    TriosMove move = checkCorners.chooseMove(modelToPass);
    ModelMockTranscripted mock = new ModelMockTranscripted(modelToPass);
    move = checkCorners.chooseMove(mock);
    Assert.assertEquals(move.toString(), "1,0,0");
    Assert.assertEquals(mock.listOfPlaced.toString(),
            "[]");
  }

  /**
   * Tests Strategy2, the go for corners strategy on an empty 3 by 3 board.
   * Checks each corner 50 times, as our method uses the addIfFlipped() method,
   * Which checks each card in hand of current player against every card
   * in the other player's hand,
   * for the two spots that corner is exposed to.
   * Also checks that the move is the best move in multiple scenerios.
   */
  @Test
  public void testStrategy2CorrectMoveEmpty3by3Board() {
    modelToPass = new TriosModel(board3by3, deck, randForShuffle);
    modelToPass.placeCard(0, 1, 0);
    ModelMockTranscripted mock = new ModelMockTranscripted(modelToPass);
    TriosMove move = checkCorners.chooseMove(mock);
    Assert.assertEquals(move.toString(), "0,0,0");
    modelToPass.placeCard(1, 2, 0);
    move = checkCorners.chooseMove(mock);
    Assert.assertEquals(move.toString(), "0,0,2");
  }

}
