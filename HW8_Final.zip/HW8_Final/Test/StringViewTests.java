import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.Board;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.IModel;
import model.TriosModel;
import view.TrioStringView;

import static org.junit.Assert.assertEquals;

/**
 * tests for the String view of the game.
 */
public class StringViewTests {

  private Board board;
  private IModel model;
  private List<GameCard> deck = new ArrayList<>();
  private TrioStringView view;
  private Appendable ap;

  @Before
  public void setUp() throws FileNotFoundException {
    deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    board = new GridReader("ConfigurationFiles/basicGridConfigForTest").gridBuilder();
    model = new TriosModel(new Random(1));
    ap = new StringBuilder();
    view = new TrioStringView(model, ap);

  }

  /**
   * tests the view of the start of a game with Red to play and 5 by 7 board.
   *
   * @throws IOException if IOExeption is thrown in running of test.
   */
  @Test
  public void testInitialView() throws IOException {
    model.startGame(board, deck);
    view.render();
    assertEquals("Player: Red\n" +
            "__    _\n" +
            "_ _   _\n" +
            "_  _  _\n" +
            "_   _ _\n" +
            "_    __\n" +
            "Hand:\n" +
            " fjfo 9 7 1 9\n" +
            " fjgro 9 7 1 9\n" +
            " bvon 9 5 6 3\n" +
            " nvowsr 9 A 3 A\n" +
            " fijfsdf 4 9 8 2\n" +
            " nvsr 9 A 3 A\n" +
            " fierjf 4 9 8 2\n" +
            " bvoen 9 5 6 3\n", ap.toString());
  }

  /**
   * tests the view of the game after Red and Blue place a card next to eachother.
   * does not battle yet.
   *
   * @throws IOException if IOExeption is thrown in running of test.
   */
  @Test
  public void testPlacedTwoCardView() throws IOException {
    model.startGame(board, deck);
    model.placeCard(0, 0, 0);
    model.placeCard(0, 1, 0);
    view.render();
    assertEquals("Player: Red\n" +
            "RB    _\n" +
            "_ _   _\n" +
            "_  _  _\n" +
            "_   _ _\n" +
            "_    __\n" +
            "Hand:\n" +
            " fjgro 9 7 1 9\n" +
            " bvon 9 5 6 3\n" +
            " nvowsr 9 A 3 A\n" +
            " fijfsdf 4 9 8 2\n" +
            " nvsr 9 A 3 A\n" +
            " fierjf 4 9 8 2\n" +
            " bvoen 9 5 6 3\n", ap.toString());
  }


  /**
   * tests view after one card is placed on the board.
   */
  @Test
  public void testPlacedOneCardView() throws IOException {
    model.startGame(board, deck);
    model.placeCard(0, 0, 0);
    view.render();
    assertEquals("Player: Blue\n" +
            "R_    _\n" +
            "_ _   _\n" +
            "_  _  _\n" +
            "_   _ _\n" +
            "_    __\n" +
            "Hand:\n" +
            " fijxf 4 9 8 2\n" +
            " fif 4 9 8 2\n" +
            " ff 4 9 8 2\n" +
            " bvoefon 9 5 6 3\n" +
            " bvowefon 9 5 6 3\n" +
            " fjfrto 9 7 1 9\n" +
            " ffo 9 7 1 9\n" +
            " fjfiro 9 7 1 9\n", ap.toString());
  }


  /**
   * tests that battle switches a card owner correctly and view shows this change. Also ensures that
   * battle does not change cards that it should not.
   */
  @Test
  public void testFlippingCardView() throws IOException {
    model.startGame(board, deck);
    model.placeCard(0, 0, 0);
    model.placeCard(0, 1, 0);
    model.battle(0, 1);
    model.placeCard(1, 2, 0);
    model.placeCard(1, 0, 0);
    model.battle(1, 0);
    view.render();
    assertEquals("Player: Red\n" +
            "BB    _\n" +
            "B R   _\n" +
            "_  _  _\n" +
            "_   _ _\n" +
            "_    __\n" +
            "Hand:\n" +
            " bvon 9 5 6 3\n" +
            " nvowsr 9 A 3 A\n" +
            " fijfsdf 4 9 8 2\n" +
            " nvsr 9 A 3 A\n" +
            " fierjf 4 9 8 2\n" +
            " bvoen 9 5 6 3\n", ap.toString());
  }
}
