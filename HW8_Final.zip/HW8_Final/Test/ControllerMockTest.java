import org.junit.Before;
import org.junit.Test;

import java.util.List;

import controller.CardDataBaseReader;
import controller.GridReader;
import controller.MockController;
import controller.TriosController;
import model.Board;
import model.GameCard;
import model.HumanPlayer;
import model.IModel;
import model.Player;
import model.StratOnePlayer;
import model.StratTwoPlayer;
import model.TriosModel;
import view.TriosGraphicsFrame;

import static org.junit.Assert.assertEquals;

/**
 * test class for the controller mocks.
 */
public class ControllerMockTest {

  List<GameCard> deck;
  Board board3by3;
  IModel model;
  TriosGraphicsFrame viewPlayer1;
  TriosGraphicsFrame viewPlayer2;
  Player human1;
  Player human2;
  Player player1;
  Player playerStrat1;
  Player player2;
  Player player22;
  TriosController controller1;
  TriosController controller2;
  TriosGraphicsFrame view;
  MockController mock1;
  MockController mock2;
  Player player1Second;

  @Before
  public void setUp() throws Exception {

    deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    board3by3 = new GridReader("ConfigurationFiles/3x3NoHoles").gridBuilder();
    model = new TriosModel();
    model.startGame(board3by3, deck);
    viewPlayer1 = new TriosGraphicsFrame(model);
    viewPlayer2 = new TriosGraphicsFrame(model);
    human1 = new HumanPlayer(model, 1);
    human2 = new HumanPlayer(model, 2);
    player1 = new StratOnePlayer(model, 1);
    player1Second = new StratOnePlayer(model, 2);
    playerStrat1 = new StratOnePlayer(model, 2);
    player2 = new StratTwoPlayer(model, 1);
    player22 = new StratTwoPlayer(model, 2);
    mock1 = new MockController(model, viewPlayer1, human1);
    mock2 = new MockController(model, viewPlayer2, human2);


  }


  /**
   * ensures that playerHasChanged is called the correct amount of times for each mock/controller.
   * run the test and close out of the game window
   */
  @Test
  public void testPlayerHasChanged() {
    model.oneSequence(0, 0, 0);
    model.oneSequence(1, 0, 0);
    model.oneSequence(2, 0, 0);
    model.oneSequence(0, 1, 0);
    model.oneSequence(1, 1, 0);
    model.oneSequence(2, 1, 0);
    assertEquals(mock1.getList().toString(), "[1 , 1 , 1 ]");
    assertEquals(mock2.getList().toString(), "[2 , 2 , 2 ]");
  }

  //ensures that SelectCard works properly.
  //close out of all windows to allow test to run.
  @Test
  public void testSelectCard() {
    mock1.selectCard(0, 1);
    mock1.selectCard(3, 1);
    mock1.selectCard(2, 1);
    mock1.selectCard(4, 1);
    mock2.selectCard(1, 2);
    mock2.selectCard(1, 2);
    mock2.selectCard(3, 2);
    mock2.selectCard(2, 2);
    assertEquals(mock1.selectedCards.toString(), "[0, 1, 3, 1, 2, 1, 4, 1]");
    assertEquals(mock2.selectedCards.toString(), "[1, 2, 1, 2, 3, 2, 2, 2]");
  }


  //ensures that SelectCard works properly.
  //close out of all windows to allow test to run.
  @Test
  public void testSelectCardAndPlace() {
    mock1.selectCard(0, 1);
    mock1.placeCard(0, 0);
    mock2.selectCard(0, 2);
    mock2.placeCard(0, 1);
    mock1.selectCard(2, 1);
    mock1.placeCard(2, 0);
    mock2.selectCard(2, 2);
    mock2.placeCard(2, 1);
    assertEquals(mock1.selectedCards.toString(), "[0, 1, 2, 1]");
    assertEquals(mock2.selectedCards.toString(), "[0, 2, 2, 2]");
    assertEquals(mock1.cardsPlaced.toString(), "[0,0, 2,0]");
    assertEquals(mock2.cardsPlaced.toString(), "[0,1, 2,1]");
  }


}
