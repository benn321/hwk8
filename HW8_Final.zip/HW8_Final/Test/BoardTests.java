import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.Board;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.TriosModel;

import static org.junit.Assert.assertEquals;

/**
 * tests all the board methods and exceptions thrown.
 */
public class BoardTests {
  private Board board5by7;
  private Board boardNoHoles;
  private Board emptyBoard;
  private TriosModel model;
  private List<GameCard> deck = new ArrayList<>();

  @Before
  public void setUp() throws FileNotFoundException {
    deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    board5by7 = new GridReader("ConfigurationFiles/basicGridConfigForTest").gridBuilder();
    boardNoHoles = new GridReader("ConfigurationFiles/NoHoleBoard").gridBuilder();
    emptyBoard = new Board();
    Random randForShuffle = new Random(1);
    model = new TriosModel(randForShuffle);
  }

  /**
   * Test countNulls on a board with only nulls, no blocked cells or GameCards.
   */
  @Test
  public void testCountNullsAllNulls() {
    assertEquals(25, boardNoHoles.countNulls());
  }

  /**
   * Test countNulls on an empty board, and thus has no nulls.
   */
  @Test
  public void testCountNullsNoNulls() {
    assertEquals(0, emptyBoard.countNulls());
  }

  /**
   * Tests countNulls on a board that has a GameCard, BlockedCells and nulls.
   */
  @Test
  public void testCountNullsMixedBoard() {
    assertEquals(15, board5by7.countNulls());
    model.startGame(board5by7, deck);
    model.placeCard(0, 0,0);
    assertEquals(14, board5by7.countNulls());
  }

  /**
   * Tests counterPlayerCards to see if it correctly counts through the card by owner in the board.
   */
  @Test
  public void testCounterPlayerCards() {
    model.startGame(boardNoHoles, deck);
    model.placeCard(0, 0, 0);
    assertEquals(1, boardNoHoles.counterPlayerCards(1));
    model.placeCard(1, 1, 0);
    assertEquals(1, boardNoHoles.counterPlayerCards(2));
    model.placeCard(2, 2, 0);
    assertEquals(1, boardNoHoles.counterPlayerCards(2));
    assertEquals(2, boardNoHoles.counterPlayerCards(1));
    model.placeCard(1, 0, 0);
    assertEquals(2, boardNoHoles.counterPlayerCards(2));
  }

  /**
   * Tests the constructor of the board that randomy builds a board.
   * Checks if correct amount of nulls.
   */
  @Test
  public void testBoardConstructor() {
    Board builtBoard = new Board(5,5,10, new Random(10));
    assertEquals(15, builtBoard.countNulls());
    assertEquals(5, builtBoard.boardRowSize());
    assertEquals(5, builtBoard.boardColSize());
  }
}
