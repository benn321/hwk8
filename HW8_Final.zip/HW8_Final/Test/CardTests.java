

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.BlockedCell;
import model.Board;
import model.Card;
import model.GameCard;
import model.TriosModel;


import static model.Values.A;
import static model.Values.EIGHT;
import static model.Values.FIVE;
import static model.Values.ONE;

/**
 * tests the card class and all its methods and exceptions being thrown.
 */
public class CardTests {
  private GameCard dragon;
  private GameCard knight;
  private BlockedCell blockedCell;
  private TriosModel model;

  @Before
  public void setUp() throws FileNotFoundException {
    //might delete later once we make a diff class
    dragon = new GameCard("Dragon", ONE, FIVE, EIGHT, A);
    knight = new GameCard("Knight", ONE, FIVE, EIGHT, A);
    blockedCell = new BlockedCell();
    Random randForShuffle = new Random(1);
    model = new TriosModel(randForShuffle);
  }

  /**
   * Tests getOwner returns zero on a blocked cell.
   */
  @Test
  public void testGetOwnerBlockedCell() {
    Assert.assertEquals(0, blockedCell.getOwner());
  }

  /**
   * tests toString on a blocked cell returns an empty string " ".
   */
  @Test
  public void testToStringBlockedCell() {
    Assert.assertEquals(" ", blockedCell.toString());
  }

  /**
   * tests toString on a GameCard.
   */
  @Test
  public void testToStringGameCard() {
    Assert.assertEquals("Dragon 8 A 5 1", dragon.toString());
  }

  /**
   * Tests that  the card owner is zero before game is played.
   * Once game started, card gets ownership, in this case player one.
   */
  @Test
  public void testGetOwnerGameCard() {
    List<Card> oneCell = new ArrayList<>();
    oneCell.add(null);
    List listOfOneCard = new ArrayList<>();
    listOfOneCard.add(oneCell);
    Board oneCellBoard = new Board(listOfOneCard);
    Assert.assertEquals(0, dragon.getOwner());
    List<GameCard> twoCardDDeck = new ArrayList<>();
    twoCardDDeck.add(dragon);
    twoCardDDeck.add(knight);
    model.startGame(oneCellBoard, twoCardDDeck);
    Assert.assertEquals(1, dragon.getOwner());
  }


}

