import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.MostFlipped;
import model.TriosMove;
import model.Board;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.ModelMockTranscripted;
import model.TriosModel;


/**
 * tests for strategy 1.
 */
public class Strategy1Tests {

  private Board board3by3;
  private TriosModel modelToPass;
  private ModelMockTranscripted mockTranscripted;
  private List<GameCard> deckSize16 = new ArrayList<>();
  private MostFlipped mostFlipped;
  private Random randForShuffle;

  @Before
  public void setUp() throws FileNotFoundException {
    List<GameCard> deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    deckSize16 = new CardDataBaseReader("ConfigurationFiles/CardFileSize16").deckBuilder();
    Board board5by7 = new GridReader("ConfigurationFiles/basicGridConfigForTest").gridBuilder();
    board3by3 = new GridReader("ConfigurationFiles/3x3NoHoles").gridBuilder();
    randForShuffle = new Random(1);
    modelToPass = new TriosModel(board5by7, deck, randForShuffle);
    Appendable ap = new StringBuilder();
    mockTranscripted = new ModelMockTranscripted(modelToPass);
    mostFlipped = new MostFlipped();
  }


  /**
   * This test checks that mostFlipped checks every single card in the hand for every single
   * valid spot on the board.
   * This specific test is on a 5by7 board with 15 open spots.
   * Each hand thus has eight cards, so it checks every single open position 8 times.
   */
  @Test
  public void testStrategy1ChecksAllValidSpots5by7Board() {
    TriosMove move = mostFlipped.chooseMove(mockTranscripted);
    Assert.assertEquals(move.toString(), "0,0,0");
    Assert.assertEquals(mockTranscripted.listOfCords.toString(),
            "[00, 00, 00, 00, 00, 00, 00, 00, " +
            "01, 01, 01, 01, 01, 01, 01, 01, " +
            "06, 06, 06, 06, 06, 06, 06, 06, " +
            "10, 10, 10, 10, 10, 10, 10, 10, " +
            "12, 12, 12, 12, 12, 12, 12, 12, " +
            "16, 16, 16, 16, 16, 16, 16, 16, " +
            "20, 20, 20, 20, 20, 20, 20, 20, " +
            "23, 23, 23, 23, 23, 23, 23, 23, " +
            "26, 26, 26, 26, 26, 26, 26, 26, " +
                    "30, 30, 30, 30, 30, 30, 30, 30, " +
                    "34, 34, 34, 34, 34, 34, 34, 34, " +
                    "36, 36, 36, 36, 36, 36, 36, 36, " +
                    "40, 40, 40, 40, 40, 40, 40, 40, " +
                    "45, 45, 45, 45, 45, 45, 45, 45, " +
                    "46, 46, 46, 46, 46, 46, 46, 46]" );
  }

  /**
   * Checks that chooseMove won't check over previously null spots that
   * have cards in them, (0,0) and (1,0)
   * Also checks that it returns the correct best move, which would be (0,1)
   * because that is the most upperleft open spot.
   */
  @Test
  public void testStrategy1ChecksAllValidSpots5by7BoardAfter2PlacedCards() {
    mockTranscripted.placeCard(0,0,0);
    mockTranscripted.placeCard(1,0,0);
    TriosMove move = mostFlipped.chooseMove(mockTranscripted);
    Assert.assertEquals(mockTranscripted.listOfCords.toString(),
            "[01, 01, 01, 01, 01, 01, 01, " +
                    "06, 06, 06, 06, 06, 06, 06, " +
                    "12, 12, 12, 12, 12, 12, 12, " +
                    "16, 16, 16, 16, 16, 16, 16, " +
                    "20, 20, 20, 20, 20, 20, 20, " +
                    "23, 23, 23, 23, 23, 23, 23, " +
                    "26, 26, 26, 26, 26, 26, 26, " +
                    "30, 30, 30, 30, 30, 30, 30, " +
                    "34, 34, 34, 34, 34, 34, 34, " +
                    "36, 36, 36, 36, 36, 36, 36, " +
                    "40, 40, 40, 40, 40, 40, 40, " +
                    "45, 45, 45, 45, 45, 45, 45, " +
                    "46, 46, 46, 46, 46, 46, 46]" );
    Assert.assertEquals(move.toString(), "0,1,0");
  }

  /**
   * Same test as above, except that the placeCard is called on the TriosModel
   * that gets passed into our mock.
   * Still works the same, which is a good sign and means that the mock works correctly.
   * And our countFlippedCards() method correctly copies the model.
   */
  @Test
  public void testStrategy1ChecksAllValidSpots5by7BoardAfterAPlacedCards2() {
    modelToPass.placeCard(0,0,0);
    modelToPass.placeCard(1,0,0);
    mockTranscripted = new ModelMockTranscripted(modelToPass);
    //checks board constructor works as expected
    Board testBoard = new Board(mockTranscripted.getBoard());
    Assert.assertEquals(testBoard.toString(), mockTranscripted.getBoard().toString());
    TriosMove move = mostFlipped.chooseMove(mockTranscripted);
    Assert.assertEquals(move.toString(), "0,1,0");
    Assert.assertEquals(mockTranscripted.listOfCords.toString(),
            "[01, 01, 01, 01, 01, 01, 01, " +
                    "06, 06, 06, 06, 06, 06, 06, " +
                    "12, 12, 12, 12, 12, 12, 12, " +
                    "16, 16, 16, 16, 16, 16, 16, " +
                    "20, 20, 20, 20, 20, 20, 20, " +
                    "23, 23, 23, 23, 23, 23, 23, " +
                    "26, 26, 26, 26, 26, 26, 26, " +
                    "30, 30, 30, 30, 30, 30, 30, " +
                    "34, 34, 34, 34, 34, 34, 34, " +
                    "36, 36, 36, 36, 36, 36, 36, " +
                    "40, 40, 40, 40, 40, 40, 40, " +
                    "45, 45, 45, 45, 45, 45, 45, " +
                    "46, 46, 46, 46, 46, 46, 46]" );
  }

  /**
   * Checks that the correct best move is displayed.
   * An empty 3x3 board is what this started as.
   * We place cards at various spots.
   */
  @Test
  public void testStrategy1NonEmpty3by3Board() {
    modelToPass = new TriosModel(board3by3, deckSize16, randForShuffle);
    modelToPass.placeCard(1,0,0); //R
    modelToPass.placeCard(0,1,0); //B
    modelToPass.placeCard(1,1,0); //R
    modelToPass.placeCard(2,0,2); //B

    mockTranscripted = new ModelMockTranscripted(modelToPass);
    TriosMove move = mostFlipped.chooseMove(mockTranscripted);
    Assert.assertEquals("0,0,0", move.toString());
    mockTranscripted.placeCard(0,2,1); //R
    mockTranscripted.placeCard(0,0,0); //B
    mockTranscripted.placeCard(2,2,0); //R
    move = mostFlipped.chooseMove(mockTranscripted); //B
    Assert.assertEquals("1,2,0", move.toString());
  }


  /**
   * Checks that the correct best move is displayed
   * after placing multiple cards down on the larger grid.
   */
  @Test
  public void testMoveWhenCardsPlaced() {
    // Simulate a game up to several moves
    mockTranscripted = new ModelMockTranscripted(modelToPass);
    mockTranscripted.placeCard(0, 0, 0);
    mockTranscripted.placeCard(0, 1, 1);
    mockTranscripted.placeCard(1, 0, 2);
    TriosMove move = mostFlipped.chooseMove(mockTranscripted);
    Assert.assertEquals("0,6,0", move.toString());
  }

  /**
   * Checks that the correct best move is displayed
   * after placing multiple cards down on the larger grid.
   */
  @Test
  public void testMoveWhenCardsPlacedFarInGame() {
    // Simulate a game up to several moves
    modelToPass.placeCard(1, 2, 0);
    modelToPass.placeCard(2, 3, 0);
    modelToPass.placeCard(0, 1, 1);
    modelToPass.placeCard(3, 4, 2);
    modelToPass.placeCard(4, 5, 2);
    modelToPass.placeCard(1, 0, 2);
    mockTranscripted = new ModelMockTranscripted(modelToPass);
    TriosMove move = mostFlipped.chooseMove(mockTranscripted);
    Assert.assertEquals("0,0,0", move.toString());
  }



}
