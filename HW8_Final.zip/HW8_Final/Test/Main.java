

import java.io.IOException;
import java.util.List;

import model.Board;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.IModel;
import model.TriosModel;

import view.SimpleStringView;
import view.TrioStringView;

/**
 * main class to test the viewing.
 */
public class Main {

  /**
   * main method to test the viewing.
   *
   * @param args arguments being passed in
   * @throws IOException if IOException is thrown in running of main.
   */
  public static void main(String[] args) throws IOException {
    Board board;
    IModel model;
    List<GameCard> deck;
    SimpleStringView view;


    deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    board = new GridReader("ConfigurationFiles/basicGridConfigForTest").gridBuilder();
    model = new TriosModel();
    Appendable ap = new StringBuilder();
    view = new TrioStringView(model, ap);

    model.startGame(board, deck);
    view.render();
    System.out.println(ap);
    model.placeCard(0, 0, 0);
    view.render();
    System.out.println(ap);
  }
}
