package providercode.model;

import java.util.List;

import model.Board;
import model.Card;
import model.GameCard;
import model.IModel;
import model.ModelFeatures;

public class ModelAdapt implements IModel {

  @Override
  public void startGame(Board board, List<GameCard> deck) {

  }

  @Override
  public void battle(int row, int col) {

  }

  @Override
  public void placeCard(int row, int col, int cardPosition) {

  }

  @Override
  public Card getCardAt(int row, int col) {
    return null;
  }

  @Override
  public void setFeatures(ModelFeatures features, int player) {

  }

  @Override
  public void oneSequence(int row, int col, int cardPosition) {

  }

  @Override
  public boolean isGameWon() {
    return false;
  }

  @Override
  public int getWinner() {
    return 0;
  }

  @Override
  public int playersTurn() {
    return 0;
  }

  @Override
  public int numRows() {
    return 0;
  }

  @Override
  public int numCols() {
    return 0;
  }

  @Override
  public List<GameCard> getCurPlayerHand() {
    return List.of();
  }

  @Override
  public Card getCardCopyAt(int row, int col) {
    return null;
  }

  @Override
  public int ownerOfCard(int row, int col) {
    return 0;
  }

  @Override
  public int getScore(int player) {
    return 0;
  }

  @Override
  public int getGridSize() {
    return 0;
  }

  @Override
  public int getGridUsableSize() {
    return 0;
  }

  @Override
  public boolean legalMove(int row, int col) {
    return false;
  }

  @Override
  public int countCardsFlipped(int row, int col, GameCard card) {
    return 0;
  }

  @Override
  public List<GameCard> getHand(int player) {
    return List.of();
  }

  @Override
  public Board getBoard() {
    return null;
  }

  @Override
  public int addIfFlipped(int row, int col, int altRow, int altCol, int toPlayCard, int altIndex) {
    return 0;
  }
}
