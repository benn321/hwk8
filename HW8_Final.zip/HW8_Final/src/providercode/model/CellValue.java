package providercode.model;

/**
 * Enum that is used to describe the cells that will be in the board.
 * Can only be one of three things, empty (no card is placed, but can be),
 * hascard (cell has a card placed), or hole (card cannot be placed)
 */
public enum CellValue {
  EMPTY,
  HASCARD,
  HOLE;
}
