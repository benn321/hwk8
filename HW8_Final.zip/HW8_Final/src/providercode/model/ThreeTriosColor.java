package providercode.model;

/**
 * Enum that is used to keep track of which player is going currently.
 * Can only be one of two things, Blue or Red, as they are the two players.
 * Game logic switches between the two players.
 */
public enum ThreeTriosColor {
  RED("Red"),
  BLUE("Blue");

  private String color;

  ThreeTriosColor(String color) {
    this.color = color;
  }

  @Override
  public String toString() {
    return color;
  }
}
