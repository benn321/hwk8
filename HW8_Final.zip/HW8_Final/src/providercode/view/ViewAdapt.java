package providercode.view;

import providercode.model.ReadOnlyThreeTriosModel;
import view.TriosFeatures;
import view.TriosGraphicsFrame;
import view.ViewFrameInterface;

public class ViewAdapt implements ViewFrameInterface {

  private Swing providerView;
  /**
   * Constructs a ThreeTriosSwing view.
   *
   * @param model the read-only model
   */
  public ViewAdapt(Swing providerView) {
    this.providerView = providerView;
    providerView.initializeComponents();
  }

  @Override
  public void makeVisible() {
  }

  /**
   * Our triosfeatures is the same thing as their PlayerActionListener.
   * It responds to certain player actions, specifically choosing a card in hand, and a cell.
   * @param features
   */
  @Override
  public void setFeatures(TriosFeatures features) {
    //is this legal?
    //will this issue be solved when we make an adapter for their controller?
    PlayerActionListener listener = (PlayerActionListener) features;
    providerView.addPlayerActionListener(listener);
  }

  @Override
  public void refresh() {
   providerView.refreshView();
  }

  @Override
  public void displayMessage(String itIsYourTurn) {

  }
}
