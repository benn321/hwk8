package providercode.view;

import cs3500.threetrios.view.ThreeTriosSwing;


/**
 * Class that represents the features that will be implemented by the Swing.
 * It will handle all user interactions on the Swing.
 */
public class FeaturesImpl implements Features {
  private final ThreeTriosSwing view;
  private int selectedCardIndex = -1;

  public FeaturesImpl(ThreeTriosSwing view) {
    this.view = view;
  }

  @Override
  public void cardClicked(boolean isRed, int index) {
    // Store the selected card index
    selectedCardIndex = index;
    // Notify listeners through the view
    view.notifyCardSelected(index);
  }

  @Override
  public void gridCellClicked(int row, int col) {
    if (selectedCardIndex != -1) {
      // Notify listeners through the view
      view.notifyCellSelected(row, col);
      // Reset selection after attempt
      selectedCardIndex = -1;
    }
  }
}