package providercode.view;

/**
 * Interface for view features that will be used by the controller.
 */
public interface Features {
  /**
   * User clicks the card, the view acts accordingly -- selects the card.
   * If the card is clicked again, it deselects that card.
   * If a different card is selected, it deselects the previous card and selects the current card.
   *
   * @param isRed boolean -- true if the current player is Red, false if is Blue
   * @param index cardIndex that is unique to each card in the hand
   */
  void cardClicked(boolean isRed, int index);

  /**
   * User clicks on the grid, the view acts accordingly.
   *
   * @param row row index of the selected grid cell
   * @param col column index of the selected grid cell
   */
  void gridCellClicked(int row, int col);
}
