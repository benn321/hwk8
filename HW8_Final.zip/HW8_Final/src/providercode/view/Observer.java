package providercode.view;

import javax.swing.SwingUtilities;

/**
 * Observer class that handles updating the view when game state changes.
 */
public class Observer implements GameObserver {
  private final ThreeTriosSwing view;

  /**
   * Constructs a ViewObserver for a specific ThreeTriosSwing view.
   * @param view the view to update on game state changes
   */
  public Observer(ThreeTriosSwing view) {
    this.view = view;
  }

  @Override
  public void onGameStateChanged() {
    SwingUtilities.invokeLater(() -> {
      view.refreshView();
    });
  }
}