package providercode.view;

/**
 * Interface that represents the game observers.
 */
public interface GameObserver {

  /**
   * What needs to happen when the game state changes.
   */
  void onGameStateChanged();
}