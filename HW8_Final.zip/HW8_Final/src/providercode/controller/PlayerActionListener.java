package providercode.controller;

/**
 * Interface that serves as listener for player actions from the view.
 */
public interface PlayerActionListener {


  /**
   * Called when the player selects a card to play.
   * @param cardIndex the index of the selected card in the player's hand.
   */
  void onCardSelected(int cardIndex);

  /**
   * Called when the player selects a cell on the board to play the card.
   * @param row the row index of the selected cell.
   * @param col the column index of the selected cell.
   */
  void onCellSelected(int row, int col);
}