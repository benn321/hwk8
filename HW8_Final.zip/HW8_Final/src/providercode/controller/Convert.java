package providercode.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import cs3500.threetrios.model.Card;
import cs3500.threetrios.model.Cell;
import cs3500.threetrios.model.CellValue;
import cs3500.threetrios.model.PlayingCard;
import cs3500.threetrios.model.Value;

/**
 * A helper class that contains the methods that converts the board and card files into their
 * respective type to be fed to the Model.
 */
public class Convert {

  protected static List<Card> convertFileToCards(File cardFile) {
    List<Card> cards = new ArrayList<>();
    Scanner scanner;
    try {
      scanner = new Scanner(cardFile);
    } catch (FileNotFoundException exception) {
      throw new IllegalArgumentException("file doesn't exist!");
    }
    List<List<String>> cardsValues = new ArrayList<>();
    while (scanner.hasNext()) {
      cardsValues.add(Arrays.asList(scanner.nextLine().split(" ")));
    }
    for (int card = 0; card < cardsValues.size(); card++) {
      List<String> cardValues = cardsValues.get(card);
      cards.add(new PlayingCard(cardValues.get(0), toValue(cardValues.get(1)),
              toValue(cardValues.get(2)), toValue(cardValues.get(3)), toValue(cardValues.get(4))));
    }
    return cards;
  }

  private static Value toValue(String value) {
    switch (value) {
      case "1":
        return Value.ONE;
      case "2":
        return Value.TWO;
      case "3":
        return Value.THREE;
      case "4":
        return Value.FOUR;
      case "5":
        return Value.FIVE;
      case "6":
        return Value.SIX;
      case "7":
        return Value.SEVEN;
      case "8":
        return Value.EIGHT;
      case "9":
        return Value.NINE;
      case "A":
        return Value.A;
      default:
        throw new IllegalArgumentException("invalid card number!");
    }
  }

  protected static Cell[][] convertFileToBoard(File boardFile) {
    Scanner scanner;
    int row;
    int col;
    List<String> boardValues = new ArrayList<>();
    try {
      scanner = new Scanner(boardFile);
    } catch (FileNotFoundException exception) {
      throw new IllegalArgumentException("file doesn't exist!");
    }
    List<String> dimension = Arrays.asList(scanner.nextLine().split(" "));
    if (dimension.size() != 2) {
      throw new IllegalArgumentException("invalid sizes!");
    }
    try {
      row = Integer.parseInt(dimension.get(0));
      col = Integer.parseInt(dimension.get(1));
    } catch (NumberFormatException exception) {
      throw new IllegalArgumentException("invalid dimensions!");
    }
    if (row < 1 || col < 1) {
      throw new IllegalArgumentException("negative or zero dimension!");
    }
    Cell[][] board = new Cell[row][col];
    while (scanner.hasNext()) {
      boardValues.add(scanner.nextLine());
    }
    if (boardValues.size() != row) {
      throw new IllegalArgumentException("incomplete file!");
    }
    for (int rowIndex = 0; rowIndex < boardValues.size(); rowIndex++) {
      String rowValues = boardValues.get(rowIndex);
      for (int colIndex = 0; colIndex < rowValues.length(); colIndex++) {
        String value = rowValues.substring(colIndex, colIndex + 1);
        if (value.equals("C")) {
          board[rowIndex][colIndex] = new Cell(CellValue.EMPTY);
        } else if (value.equals("X")) {
          board[rowIndex][colIndex] = new Cell(CellValue.HOLE);
        } else {
          throw new IllegalArgumentException("invalid board value!");
        }
      }
    }
    return board;
  }
}
