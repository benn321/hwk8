package view;

import java.io.IOException;

/**
 * represents the overall view interface for how the game will be viewed.
 */
public interface SimpleStringView {

  /**
   * Renders a model in some manner (e.g. as text, or as graphics, etc.).
   *
   * @throws IOException if the rendering fails for some reason
   */
  void render() throws IOException;
}
