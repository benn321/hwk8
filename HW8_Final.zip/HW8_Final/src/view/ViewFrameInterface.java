package view;

/**
 * interface to represent the frame view as a whole.
 */
public interface ViewFrameInterface {

  /**
   * makes the frame interface.
   */
  void makeVisible();

  /**
   * sets the features.
   */
  void setFeatures(TriosFeatures features);

  /**
   * refreshes the frame.
   */
  void refresh();

  void displayMessage(String itIsYourTurn);
}
