package view;

/**
 * interface for the Trios features to be implemented in the controller.
 */
public interface TriosFeatures {
  /**
   * handles whena  user selects a card in the hand.
   * @param handIndex hand ndex of the card.
   */
  int selectCard(int handIndex, int owner);

  /**
   * handels when a card is placed on the board.
   * @param row row number.
   * @param col col number.
   */
  void placeCard(int row, int col);

}
