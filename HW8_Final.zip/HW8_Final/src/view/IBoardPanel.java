package view;

/**
 * interface to represent a board panel.
 */
public interface IBoardPanel {

  /**
   * refreshes the Board Panel.
   */
  void refresh();

  /**
   * sets the features, that are yet to implemented.
   *
   * @param features that user can do, and connect controller and view.
   */
  void setFeatures(TriosFeatures features);
}
