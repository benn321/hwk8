package view;

import javax.swing.JOptionPane;
import javax.swing.JFrame;

import java.awt.BorderLayout;
import java.awt.Dimension;

import model.ReadonlyThreeTriosModel;

/**
 * Frame that puts all the panels together, one for the board, one for each hand (so 2).
 */
public class TriosGraphicsFrame extends JFrame implements ViewFrameInterface {
  private final BoardPanel boardPanel;
  private final HandPanel playerOneHandPanel;
  private final HandPanel playerTwoHandPanel;
  int windowWidth = 1000;
  int windowHeight = 1000;

  /**
   * Constructor that takes a readonly model and features.
   *
   * @param model    readonly model to properly draw frame.
   */
  public TriosGraphicsFrame(ReadonlyThreeTriosModel model) {
    this.setTitle("Three Trios Game");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(windowWidth, windowHeight);
    this.setLayout(new BorderLayout());

    // Initialize custom panels for board and hands
    boardPanel = new BoardPanel(model);
    playerOneHandPanel = new HandPanel(model, 1); // Assuming 1 represents Player 1
    playerTwoHandPanel = new HandPanel(model, 2); // Assuming 2 represents Player 2


    boardPanel.setPreferredSize(new Dimension((windowWidth / 4) * 3, windowHeight));
    playerOneHandPanel.setPreferredSize(new Dimension(windowWidth / 8, windowHeight));
    playerTwoHandPanel.setPreferredSize(new Dimension(windowWidth / 8, windowHeight));

    // Add panels to the frame layout
    this.add(boardPanel, BorderLayout.CENTER);
    this.add(playerOneHandPanel, BorderLayout.WEST);
    this.add(playerTwoHandPanel, BorderLayout.EAST);

    this.pack();
  }


  /**
   * sets the features.
   * @param features are the features for controller use.
   */
  public void setFeatures(TriosFeatures features) {
    this.boardPanel.setFeatures(features);
    this.playerOneHandPanel.setFeatures(features);
    this.playerTwoHandPanel.setFeatures(features);
  }


  /**
   *makes it visible.
   */
  @Override
  public void makeVisible() {
    super.setVisible(true);
  }

  /**
   *refreshes the frame.
   */
  @Override
  public void refresh() {
    boardPanel.refresh();
    playerOneHandPanel.refresh();
    playerTwoHandPanel.refresh();
  }

  @Override
  public void displayMessage(String message) {
    JOptionPane.showMessageDialog(null, message);
  }


}

