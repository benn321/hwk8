package model;

/**
 * The Card interface represents a basic structure for a card
 * object that has an owner and a string representation.
 * Classes implementing this interface should provide a way to
 * retrieve the owner of the card and represent the card as a string.
 */
public interface Card {

  /**
   * Gets the owner of this card.
   *
   * @return an integer representing the owner of the card
   */
  int getOwner();

  /**
   * Returns a string representation of this card.
   *
   * @return a string representing the card
   */
  @Override
  String toString();

  /**
   * Gets western value of the card.
   * Unless BlockedCell, which is null.
   * @return the Values of the west.
   */
  Values getWest();

  /**
   * Gets eastern value of the card.
   * Unless BlockedCell, which is null.
   * @return the Values of the east.
   */
  Values getEast();

  /**
   * Gets northern value of the card.
   * Unless BlockedCell, which is null.
   * @return the Values of the north.
   */
  Values getNorth();

  /**
   * Gets southern value of the card.
   * Unless BlockedCell, which is null.
   * @return the Values of the south.
   */
  Values getSouth();
}