package model;

import view.TriosFeatures;

/**
 * interface to represent a player, either human or ai.
 */
public interface Player {

  /**
   * sets the features in the player to the feature that is passed in.
   * @param features view features that are passed in and set.
   */
  void setFeatures(TriosFeatures features);

  /**
   * makes a move for the player.
   */
  void makeAMove();

  /**
   * gets the players number, either 1 or 2.
   * @return
   */
  int getNum();
}
