package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


import static java.util.Collections.shuffle;

/**
 * Represents the main game model for the Trios game, managing the game state, player hands,
 * and interactions between cards on the board. Implements the {@code IModel} interface.
 */
public class TriosModel implements IModel {
  private Board grid;
  private List<GameCard> deck;
  private List<GameCard> hand1;
  private List<GameCard> hand2;
  private int handToPlay; // INVARIANT: Will always be 1 or 2.
  private Random rand;
  private Boolean gameWon = false;
  private Boolean gameOver = false;
  private Boolean gameStarted = false;
  private ModelFeatures features1;
  private ModelFeatures features2;

  /**
   * Default constructor for convenience. Initializes an empty deck, two player hands,
   * and a random number generator.
   */
  public TriosModel() {
    this.deck = new ArrayList<>();
    this.rand = new Random();
    this.hand1 = new ArrayList<>();
    this.hand2 = new ArrayList<>();
    this.handToPlay = 1;
  }

  /**
   * Constructor that allows specifying a {@code Random} instance for controlled randomness.
   *
   * @param rand a {@code Random} instance for controlling the random shuffle of cards
   */
  public TriosModel(Random rand) {
    this.deck = new ArrayList<>();
    this.rand = rand;
    this.hand1 = new ArrayList<>();
    this.hand2 = new ArrayList<>();
    this.handToPlay = 1;
  }

  /**
   * copies another trios model.
   *
   * @param triosModel model to be copied
   */
  public TriosModel(TriosModel triosModel) {
    this.deck = new ArrayList<>();
    for (int i = 0; i < triosModel.deck.size(); i++) {
      deck.add(triosModel.deck.get(i));
    }
    this.hand1 = new ArrayList<>();
    for (int i = 0; i < triosModel.getHand(1).size(); i++) {
      GameCard cardToAdd = new GameCard(triosModel.getHand(1).get(i));
      hand1.add(cardToAdd);
    }
    this.hand2 = new ArrayList<>();
    for (int i = 0; i < triosModel.getHand(2).size(); i++) {
      GameCard cardToAdd = new GameCard(triosModel.getHand(2).get(i));
      hand2.add(cardToAdd);
    }

    this.grid = new Board(triosModel.getBoard());
    this.rand = triosModel.rand;
    this.handToPlay = triosModel.handToPlay;
    this.gameWon = triosModel.gameWon;
    this.gameOver = triosModel.gameOver;
    this.gameStarted = triosModel.gameStarted;
  }

  /**
   * starts game constructor.
   *
   * @param board board to start game.
   * @param deck  deck to deal from.
   * @param rand  random to use for shuffling.
   */
  public TriosModel(Board board, List<GameCard> deck, Random rand) {
    this.deck = deck;
    this.rand = rand;
    this.handToPlay = 1;
    this.gameWon = false;
    this.gameOver = false;
    this.gameStarted = true;
    this.grid = board;
    this.hand1 = new ArrayList<>();
    this.hand2 = new ArrayList<>();


    int cardCellCount = board.countNulls();
    if (cardCellCount > deck.size()) {
      throw new IllegalArgumentException("Card cell count is greater than deck size");
    }

    shuffle(this.deck, rand);
    int amountToDeal = (cardCellCount + 1) / 2;

    for (int i = 0; i < amountToDeal; i++) {
      GameCard nextCard1 = this.deck.remove(0);
      nextCard1.changeOwner(1);
      this.hand1.add(nextCard1);
      GameCard nextCard2 = this.deck.remove(0);
      nextCard2.changeOwner(2);
      this.hand2.add(nextCard2);
    }
    //features1.playerHasChanged();
  }


  /**
   * Checks if the game is over based on the board state. Throws an exception if the game
   * has ended.
   *
   * @throws IllegalStateException if the game is over
   */
  private void gameOverException() {
    if (grid.countNulls() == 0) {
      throw new IllegalStateException("Game is over");
    }
  }

  private void checkGameStarted() {
    if (!gameStarted) {
      throw new IllegalStateException("Game is not started");
    }
  }


  /**
   * Starts the game by setting up the board and dealing cards to players. The game cannot
   * be started if it has already begun or if there is an issue with the board or deck.
   *
   * @param board the game board, containing cells for cards and blocked cells
   * @param deck  a list of {@code GameCard} objects to form the deck
   * @throws IllegalStateException    if the game has already started or is over
   * @throws IllegalArgumentException if the board or deck is invalid
   */
  @Override
  public void startGame(Board board, List<GameCard> deck) {
    this.grid = board;
    this.deck = deck;
    gameOverException();
    if (gameStarted) {
      throw new IllegalStateException("Game already started");
    }
    this.gameStarted = true;

    int cardCellCount = board.countNulls();
    if (cardCellCount > deck.size()) {
      throw new IllegalArgumentException("Card cell count is greater than deck size");
    }

    shuffle(this.deck, rand);
    int amountToDeal = (cardCellCount + 1) / 2;

    for (int i = 0; i < amountToDeal; i++) {
      GameCard nextCard1 = this.deck.remove(0);
      nextCard1.changeOwner(1);
      this.hand1.add(nextCard1);
      GameCard nextCard2 = this.deck.remove(0);
      nextCard2.changeOwner(2);
      this.hand2.add(nextCard2);
    }
  }


  /**
   * Conducts a battle between cards at a specified position on the board. Battles are
   * initiated based on adjacent cells to the card being placed.
   *
   * @param row the row position of the card initiating the battle
   * @param col the column position of the card initiating the battle
   * @throws IllegalArgumentException if the specified cell is empty or blocked
   */
  @Override
  public void battle(int row, int col) {
    checkGameStarted();
    if (grid.getTile(row, col) == null || grid.getTile(row, col) instanceof BlockedCell) {
      throw new IllegalArgumentException("Cell is empty or blocked");
    }
    GameCard currentTile = (GameCard) grid.getTile(row, col);

    // Check adjacent cells and initiate battles in each direction as needed
    if (row - 1 >= 0 && grid.getTile(row - 1, col) instanceof GameCard
            && currentTile.battleNorth((GameCard) grid.getTile(row - 1, col))) {
      battle(row - 1, col);
    }
    if (col + 1 < grid.boardColSize() && grid.getTile(row, col + 1) instanceof GameCard
            && currentTile.battleEast((GameCard) grid.getTile(row, col + 1))) {
      battle(row, col + 1);
    }
    if (row + 1 < grid.boardRowSize() && grid.getTile(row + 1, col) instanceof GameCard
            && currentTile.battleSouth((GameCard) grid.getTile(row + 1, col))) {
      battle(row + 1, col);
    }
    if (col - 1 >= 0 && grid.getTile(row, col - 1) instanceof GameCard
            && currentTile.battleWest((GameCard) grid.getTile(row, col - 1))) {
      battle(row, col - 1);
    }
    if (features1 != null && features2 != null) {
      this.features1.refreshView();
      this.features2.refreshView();
    }

  }

  /**
   * Places a card on the grid at a specified position for a specified player.
   *
   * @param row          the row on the board to place the card
   * @param col          the column on the board to place the card
   * @param cardPosition the position of the card in the player's hand
   * @throws IllegalArgumentException if the row or column are invalid or the cell is occupied
   */
  @Override
  public void placeCard(int row, int col, int cardPosition) {
    checkGameStarted();
    gameOverException();
    if (col >= grid.boardColSize() || col < 0 || row >= grid.boardRowSize() || row < 0) {
      throw new IllegalArgumentException("Invalid row or column");
    } else if (grid.getTile(row, col) != null || grid.getTile(row, col) instanceof BlockedCell) {
      throw new IllegalArgumentException("Can't place card in this cell as it is blocked or "
              + "occupied");
    } else {
      if (handToPlay == 1) {
        playerOnePlace(row, col, cardPosition);
      } else {
        playerTwoPlace(row, col, cardPosition);
      }
    }
    // Switches player turn
    handToPlay = 3 - handToPlay;
    if (features1 != null && features2 != null) {
      this.features1.refreshView();
      this.features2.refreshView();

    }
  }

  @Override
  public void oneSequence(int row, int col, int cardPosition) {
    placeCard(row, col, cardPosition);
    battle(row, col);
    if (features1 != null && features2 != null) {
      if (handToPlay == 1) {
        features1.playerHasChanged();
      }
      if (handToPlay == 2) {
        features2.playerHasChanged();
      }
    }
  }

  /**
   * Helper method to place a card from player one's hand on the grid.
   *
   * @param row          the row on the board to place the card
   * @param col          the column on the board to place the card
   * @param cardPosition the position of the card in player one's hand
   */
  private void playerOnePlace(int row, int col, int cardPosition) {
    if (hand1.size() < cardPosition || cardPosition < 0) {
      throw new IllegalArgumentException("Invalid card position");
    }
    Card cardToPlace = hand1.remove(cardPosition);
    grid.set(row, col, cardToPlace);
  }

  /**
   * Helper method to place a card from player two's hand on the grid.
   *
   * @param row          the row on the board to place the card
   * @param col          the column on the board to place the card
   * @param cardPosition the position of the card in player two's hand
   */
  private void playerTwoPlace(int row, int col, int cardPosition) {
    if (hand2.size() < cardPosition || cardPosition < 0) {
      throw new IllegalArgumentException("Invalid card position");
    }
    Card cardToPlace = hand2.remove(cardPosition);
    grid.set(row, col, cardToPlace);
  }

  /**
   * Retrieves the card located at a specific position on the board.
   *
   * @param row the row index of the desired card.
   * @param col the column index of the desired card.
   * @return the Card at the specified position on the board, or null if the cell is empty.
   */
  @Override
  public Card getCardAt(int row, int col) {
    return grid.getTile(row, col);
  }

  @Override
  public void setFeatures(ModelFeatures features, int player) {
    if (player == 1) {
      this.features1 = features;
    }
    if (player == 2) {
      this.features2 = features;
    }
  }


  /**
   * Determines the winner by counting the cards owned by each player on the board.
   * Should only be called when the game is over.
   *
   * @return 1 or 2 indicating the winning player, or 0 if the game is a tie.
   * @throws IllegalStateException if the game is not over.
   */
  @Override
  public int getWinner() {
    if (!gameOver) {
      throw new IllegalStateException("Game is not over, there is no winner yet.");
    }
    if (grid.counterPlayerCards(1) + hand1.size() > grid.counterPlayerCards(2) +
            hand2.size()) {
      return 1;
    }
    if (grid.counterPlayerCards(1) + hand1.size() < grid.counterPlayerCards(2 +
            hand2.size())) {
      return 2;
    } else {
      return 0;
    }
  }

  /**
   * Checks if the game has been won. A game is considered won when the board is full.
   *
   * @return {@code true} if the game is won, {@code false} otherwise.
   */
  @Override
  public boolean isGameWon() {
    checkGameStarted();
    if (grid.countNulls() == 0) {
      gameWon = true;
      gameOver = true;
    }
    return gameWon;
  }

  /**
   * Returns the current player's turn.
   *
   * @return 1 if it is player one's turn, 2 if it is player two's turn.
   */
  public int playersTurn() {
    return handToPlay;
  }

  /**
   * Returns the number of rows in the board.
   *
   * @return the number of rows on the board
   */
  @Override
  public int numRows() {
    return this.grid.boardRowSize();
  }

  /**
   * Returns the number of columns in the board.
   *
   * @return the number of columns on the board
   */
  @Override
  public int numCols() {
    return this.grid.boardColSize();
  }


  /**
   * Retrieves the current player's hand, which is a list of cards available to them.
   *
   * @return a copy of the hand that is about to play.
   */
  @Override
  public List<GameCard> getCurPlayerHand() {
    return getHand(handToPlay);
  }


  /**
   * Returns a copy of the card at given row and col.
   * The real card at that location cannot be retrieved and mutated using this method.
   *
   * @param row of card.
   * @param col of card.
   * @return a copy of Card.
   */
  @Override
  public Card getCardCopyAt(int row, int col) {
    if (grid.getTile(row, col) instanceof GameCard) {
      return new GameCard((GameCard) grid.getTile(row, col));
    } else if (grid.getTile(row, col) instanceof BlockedCell) {
      return new BlockedCell();
    } else {
      return null;
    }
  }

  /**
   * Returns owner of GameCard at given position.
   * If it is an instanceof Null or BlockedCell, an illegalargumentexception is thrown.
   *
   * @param row of given card.
   * @param col of given card.
   * @return the owner of the card.
   */
  public int ownerOfCard(int row, int col) {
    if (grid.getTile(row, col) instanceof GameCard) {
      return grid.getTile(row, col).getOwner();
    } else {
      throw new IllegalArgumentException("Not an instance of GameCard");
    }
  }

  /**
   * Returns the score of a given player.
   *
   * @param player int representing player.
   * @return score (amount of cards on board) of a given player.
   */
  @Override
  public int getScore(int player) {
    return grid.counterPlayerCards(player);
  }


  @Override
  public int getGridSize() {
    return numRows() * numCols();
  }


  @Override
  public int getGridUsableSize() {
    return grid.countNulls();
  }


  @Override
  public boolean legalMove(int row, int col) {
    try {
      return grid.getTile(row, col) == null;
    } catch (IllegalArgumentException e) {
      return false;
    }
  }


  /**
   * simulates a card being places in a given row and col in a copy of the model.
   * This checks how many cards this move would flip.
   *
   * @param row  of where card is placed.
   * @param col  of where card is placed.
   * @param card the card being placed.
   * @return number of cards that would flip as a result of this move.
   */
  @Override
  public int countCardsFlipped(int row, int col, GameCard card) {
    TriosModel copyOfModel = new TriosModel(this);
    checkGameStarted();
    gameOverException();
    int curCount = copyOfModel.getScore(card.getOwner());
    int player = card.getOwner();
    try {
      copyOfModel.placeCard(row, col, copyOfModel.getHand(player).indexOf(card));
      copyOfModel.battle(row, col);
    } catch (IllegalArgumentException e) {
      return 0;
    }

    int afterBattle = copyOfModel.getScore(card.getOwner());
    return afterBattle - curCount;
  }

  @Override
  public List<GameCard> getHand(int player) {
    List<GameCard> newHand = new ArrayList<>();
    if (player == 1) {
      for (GameCard gameCard : hand1) {
        newHand.add(gameCard);
      }
    } else if (player == 2) {
      for (GameCard gameCard : hand2) {
        newHand.add(gameCard);
      }
    } else {
      throw new IllegalArgumentException("Invalid player");
    }
    return newHand;
  }


  @Override
  public Board getBoard() {
    return new Board(this.grid);
  }


  @Override
  public int addIfFlipped(int row, int col, int altRow, int altCol, int toPlayCard, int altIndex) {
    try {
      IModel copyOfModel = new TriosModel(this);
      copyOfModel.placeCard(row, col, toPlayCard);
      copyOfModel.placeCard(altRow, altCol, altIndex);
      copyOfModel.battle(altRow, altCol);
      if (copyOfModel.getCardAt(row, col).getOwner() ==
              copyOfModel.getCardAt(altRow, altCol).getOwner()) {
        return 1;
      }
    } catch (IllegalArgumentException ignored) {
    }
    return 0;
  }
}

