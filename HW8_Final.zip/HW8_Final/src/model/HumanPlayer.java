package model;

import view.TriosFeatures;

/**
 * represents a human player of the game.
 */
public class HumanPlayer implements Player {
  private int player;

  /**
   * constructor for a human player.
   * @param model the model the player is using just used for consistency and
   *              possibly for extendability
   * @param player the player number
   */
  public HumanPlayer(ReadonlyThreeTriosModel model , int player) {
    this.player = player;
  }

  @Override
  public void setFeatures(TriosFeatures features) {
    // nothing because human player does not need ot set features and is never called
  }

  @Override
  public void makeAMove() {
    // nothing because makeAMove is never called on a human player
  }

  @Override
  public int getNum() {
    return player;
  }
}
