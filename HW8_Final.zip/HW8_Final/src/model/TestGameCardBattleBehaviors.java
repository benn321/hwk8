package model;

import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;


import static model.Values.A;
import static model.Values.EIGHT;
import static model.Values.FIVE;
import static model.Values.ONE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


/**
 * tests the battle behaviors of each in the GameCard class.
 */
public class TestGameCardBattleBehaviors {


  private GameCard dragon;
  private GameCard knight;

  @Before
  public void setUp() throws FileNotFoundException {

    // Create specific game cards for battle testing
    dragon = new GameCard("Dragon", ONE, FIVE, EIGHT, FIVE);
    knight = new GameCard("Knight", A, A, A, A);
  }

  @Test
  public void testNorthBattle() {
    // Set ownership of dragon and knight for initial conditions
    dragon.changeOwner(1);
    knight.changeOwner(2);

    // Test that dragon loses the north battle against knight
    assertFalse(dragon.battleNorth(knight));
    assertEquals(1, dragon.getOwner());
    assertEquals(2, knight.getOwner());

    // Test that knight wins the north battle against dragon and takes ownership
    assertTrue(knight.battleNorth(dragon));
    assertEquals(2, dragon.getOwner());
    assertEquals(2, knight.getOwner());
  }

  @Test
  public void testSouthBattle() {
    // Set initial ownership of dragon and knight
    dragon.changeOwner(1);
    knight.changeOwner(2);

    // Test that dragon loses the south battle against knight
    assertFalse(dragon.battleSouth(knight));
    assertEquals(1, dragon.getOwner());
    assertEquals(2, knight.getOwner());

    // Test that knight wins the south battle against dragon and takes ownership
    assertTrue(knight.battleSouth(dragon));
    assertEquals(2, dragon.getOwner());
    assertEquals(2, knight.getOwner());
  }

  @Test
  public void testEastBattle() {
    // Set initial ownership of dragon and knight
    dragon.changeOwner(1);
    knight.changeOwner(2);

    // Test that dragon loses the east battle against knight
    assertFalse(dragon.battleEast(knight));
    assertEquals(1, dragon.getOwner());
    assertEquals(2, knight.getOwner());

    // Test that knight wins the east battle against dragon and takes ownership
    assertTrue(knight.battleEast(dragon));
    assertEquals(2, dragon.getOwner());
    assertEquals(2, knight.getOwner());
  }

  @Test
  public void testWestBattle() {
    // Set initial ownership of dragon and knight
    dragon.changeOwner(1);
    knight.changeOwner(2);

    // Test that dragon loses the west battle against knight
    assertFalse(dragon.battleWest(knight));
    assertEquals(1, dragon.getOwner());
    assertEquals(2, knight.getOwner());

    // Test that knight wins the west battle against dragon and takes ownership
    assertTrue(knight.battleWest(dragon));
    assertEquals(2, dragon.getOwner());
    assertEquals(2, knight.getOwner());
  }
}
