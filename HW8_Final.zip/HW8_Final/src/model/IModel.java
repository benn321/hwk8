package model;

import java.util.List;


/**
 * Represents the game model, defining core methods for managing the game state, gameplay, and
 * retrieving status information. Allows for extensibility in case future iterations of models
 * need to be implemented.
 */
public interface IModel extends ReadonlyThreeTriosModel {

  /**
   * Starts the game by initializing the board and dealing cards to players.
   *
   * @param board a Board object containing nulls and blocked cells for players to play on.
   * @param deck  a list of GameCard objects that are dealt to players. The deck must be at
   *              least one card larger than the number of nulls in the board.
   * @throws IllegalArgumentException if the board or deck are invalid.
   */
  void startGame(Board board, List<GameCard> deck);



  /**
   * Conducts a battle between cards on the board at a specified location. This method is
   * typically called after a card is placed to initiate battles with adjacent cards.
   *
   * @param row the row position of the card initiating the battle.
   * @param col the column position of the card initiating the battle.
   * @throws IllegalArgumentException if the specified cell is empty or blocked.
   */
  void battle(int row, int col);

  /**
   * Places a card on the board grid at a specified position for the given player.
   *
   * @param row          the row on the board where the card will be placed.
   * @param col          the column on the board where the card will be placed.
   * @param cardPosition the index of the card in the player's hand to be placed.
   * @throws IllegalArgumentException if the row, column, or card position is invalid, or if
   *                                  the cell is occupied or blocked.
   */
  void placeCard(int row, int col, int cardPosition);


  /**
   * Retrieves the card located at the specified position on the board.
   *
   * @param row the row of the board position to retrieve the card from.
   * @param col the column of the board position to retrieve the card from.
   * @return the Card located at the specified row and column, or null if the cell is empty.
   * @throws IllegalArgumentException if the specified position is out of bounds.
   */
  Card getCardAt(int row, int col);

  void setFeatures(ModelFeatures features, int player);

  /**
   * combines the placing and battling of a move.
   * @param row row number of placement.
   * @param col col number of placment.
   * @param cardPosition index in hand of card to be placed.
   */
  void oneSequence(int row, int col, int cardPosition);
}
