package model;

import view.TriosFeatures;

/**
 * represents an ai player that uses strategy one.
 */
public class StratOnePlayer implements Player {
  private TriosFeatures features;
  private ReadonlyThreeTriosModel model;
  private int player;

  /**
   * constructor for the stratOnePlayer.
   *
   * @param model  the read only version of the model that is used for the strategy.
   * @param player the player number, 1 or 2.
   */
  public StratOnePlayer(ReadonlyThreeTriosModel model, int player) {
    this.model = model;
    this.player = player;
  }

  @Override
  public void setFeatures(TriosFeatures features) {
    this.features = features;
  }

  @Override
  public void makeAMove() {
    MostFlipped bestMove = new MostFlipped();
    TriosMove move = bestMove.chooseMove(model);
    features.selectCard(move.handPos, player);
    features.placeCard(move.row, move.col);
  }

  @Override
  public int getNum() {
    return this.player;
  }


}
