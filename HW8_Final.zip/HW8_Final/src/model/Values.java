package model;

/**
 * Enum representing the possible values for card attributes in the Trios game.
 * Each value has an associated integer for comparison and other operations.
 */
public enum Values  {
  ONE(1), TWO(2), THREE(3), FOUR(4), FIVE(5),
  SIX(6), SEVEN(7), EIGHT(8), NINE(9), A(10);

  public final int value;

  /**
   * Creates a {@code Values} instance with the specified integer value.
   *
   * @param value the integer representation of this value
   */
  Values(int value) {
    this.value = value;
  }

  /**
   * Returns the string representation of this value.
   * If the value is 10, it is represented as "A"; otherwise, the integer is returned as a string.
   *
   * @return the string representation of this value
   */
  @Override
  public String toString() {
    return this.value == 10 ? "A" : String.valueOf(this.value);
  }

  /**
   * Retrieves the integer value of this enum constant.
   *
   * @return the integer value associated with this enum constant
   */
  protected int getValue() {
    return value;
  }
}
