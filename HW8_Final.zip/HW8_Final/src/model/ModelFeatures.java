package model;

/**
 * the model features interface that is used to decouple aspects of the game.
 */
public interface ModelFeatures {

  /**
   * is used to indicate to the controller that the player has changed.
   * allows the controller to progress aspects of the game based on this fact.
   */
  void playerHasChanged();

  /**
   * used to refresh the view when needed.
   */
  void refreshView();
}
