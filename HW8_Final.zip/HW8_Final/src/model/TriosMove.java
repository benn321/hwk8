package model;

/**
 * Object that AutoMoves return that contains the row, column, and
 * handPosition/index of the best move to do.
 */
public class TriosMove {
  int row;
  int col;
  int handPos;
  int count;

  /**
   * Constructor for TriosMove.
   * @param row in grid for where card should be placed.
   * @param col in grid for where card should be placed.
   * @param handPos index of card that should be played in the hand of the player.
   * @param count the amount of cards that can flip the move. Used for Corners strategy
   */
  public TriosMove(int row, int col, int handPos, int count) {
    this.row = row;
    this.col = col;
    this.handPos = handPos;
    this.count = count;
  }

  /**
   * Constructor for TriosMove.
   * @param row in grid for where card should be placed.
   * @param col in grid for where card should be placed.
   * @param handPos index of card that should be played in the hand of the player.
   */
  public TriosMove(int row, int col, int handPos) {
    this.row = row;
    this.col = col;
    this.handPos = handPos;
  }


  /**
   * Method for getting the count.
   * @return the count from this object.
   */
  public int getCount() {
    return count;
  }

  /**
   * writes a TriosMove as a string.
   * @return a String of the trios move.
   *     Would look something like this: "0,0,0" or "2,2,2".
   */
  public String toString() {
    return Integer.toString(this.row) + "," + Integer.toString(this.col) + "," +
            Integer.toString(this.handPos);
  }
}
