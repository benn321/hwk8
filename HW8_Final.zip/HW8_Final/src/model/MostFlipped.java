package model;

import java.util.List;

/**
 * Representation of the strategy that checks which card in the hand.
 * Would flip the most cards on the board.
 */
public class MostFlipped implements AutoMoves {

  /**
   * Chooses the best move in the given scenerio.
   *
   * @param model of the current game.
   * @return the best possible move.
   */
  @Override
  public TriosMove chooseMove(ReadonlyThreeTriosModel model) {
    Boolean hasBeenUpdated = false;
    int currentMax = 0;
    int maxRow = 0;
    int maxCol = 0;
    int handIndex = 0;
    List<GameCard> hand = model.getCurPlayerHand();

    for (int row = 0; row < model.numRows(); row++) {
      for (int col = 0; col < model.numCols(); col++) {
        if (model.legalMove(row, col)) {
          for (int handSize = 0; handSize < hand.size(); handSize++) {
            int tempMax = model.countCardsFlipped(row, col, hand.get(handSize));
            if (tempMax > currentMax) {
              hasBeenUpdated = true;
              currentMax = tempMax;
              maxRow = row;
              maxCol = col;
              handIndex = handSize;
            }
          }
        }
      }
    }
    if (hasBeenUpdated) {
      return new TriosMove(maxRow, maxCol, handIndex);
    } else {
      return new UpperLeftMove().chooseMove(model);
    }
  }
}
