package model;

/**
 * Representation of strategy needed to implement that attempts to place cards in corners.
 * More of a "defensive" move in the game.
 */
public class GoForCorners implements AutoMoves {
  TriosMove moveAttempt;

  /**
   * Checks which would be the best move in this specific strategy of going for the corners.
   *
   * @param model of the current game.
   * @return TriosMove, which is row, col, and card Index in hand that would be the best move.
   */
  @Override
  public TriosMove chooseMove(ReadonlyThreeTriosModel model) {


    moveAttempt = new TriosMove(-1, -1, -1, 1000000000);

    if (model.getCardCopyAt(0, 0) == null) {
      moveAttempt = tryTopLeft(model);
    }
    if (model.getCardCopyAt(0, model.numCols() - 1) == null) {
      moveAttempt = tryTopRight(moveAttempt, moveAttempt.getCount(), model);
    }

    if (model.getCardCopyAt(model.numRows() - 1, 0) == null) {
      moveAttempt = tryBotLeft(moveAttempt, moveAttempt.getCount(), model);
    }

    if (model.getCardCopyAt(model.numRows() - 1, model.numCols() - 1) == null) {
      moveAttempt = tryBotRight(moveAttempt, moveAttempt.getCount(), model);
    }

    if (moveAttempt.getCount() != 1000000000) {
      return moveAttempt;
    } else {
      AutoMoves upperLeft = new UpperLeftMove();
      return upperLeft.chooseMove(model);
    }
  }


  /**
   * trys bottom right move.
   *
   * @param moveAttempt the previous move attempt.
   * @param numThatFlip the amount of opponent player cards that flip that move.
   * @param model       the model that is being used for the strategy.
   * @return best possible move attempt given the scenerio.
   */
  private TriosMove tryBotRight(TriosMove moveAttempt, int numThatFlip,
                                ReadonlyThreeTriosModel model) {

    for (int toPlayCard = 0; toPlayCard < model.getCurPlayerHand().size(); toPlayCard++) {
      int count = 0;
      for (int altIndex = 0; altIndex < model.getHand(3 - model.playersTurn()).size();
           altIndex++) {
        int first = addIfFlipped(model.numRows() - 1, model.numCols() - 1, model,
                model.numRows() - 2, model.numCols() - 1, toPlayCard, altIndex);
        int second = addIfFlipped(model.numRows() - 1, model.numCols() - 1, model,
                model.numRows() - 1, model.numCols() - 2, toPlayCard, altIndex);
        count = count + first + second;
      }
      if (count < numThatFlip) {
        numThatFlip = count;
        moveAttempt = new TriosMove(model.numRows() - 1, model.numCols() - 1, toPlayCard,
                count);
      }
    }
    return moveAttempt;
  }

  /**
   * trys bottom left move.
   *
   * @param moveAttempt the previous move attempt.
   * @param numThatFlip the amount of opponent player cards that flip that move.
   * @param model       the model that is being used for the strategy.
   * @return best possible move attempt given the scenerio.
   */
  private TriosMove tryBotLeft(TriosMove moveAttempt, int numThatFlip,
                               ReadonlyThreeTriosModel model) {

    for (int toPlayCard = 0; toPlayCard < model.getCurPlayerHand().size(); toPlayCard++) {
      int count = 0;
      for (int altIndex = 0; altIndex < model.getHand(3 - model.playersTurn()).size();
           altIndex++) {
        int first = addIfFlipped(model.numRows() - 1, 0, model, model.numRows() - 2,
                0, toPlayCard, altIndex);
        int second = addIfFlipped(model.numRows() - 1, 0, model,
                model.numRows() - 1,
                1, toPlayCard, altIndex);
        count = count + first + second;
      }
      if (count < numThatFlip) {
        numThatFlip = count;
        moveAttempt = new TriosMove(model.numRows() - 1, 0, toPlayCard, count);
      }
    }
    return moveAttempt;
  }

  /**
   * trys top right move.
   *
   * @param moveAttempt the previous move attempt.
   * @param numThatFlip the amount of opponent player cards that flip that move.
   * @param model       the model that is being used for the strategy.
   * @return best possible move attempt given the scenerio.
   */
  private TriosMove tryTopRight(TriosMove moveAttempt, int numThatFlip,
                                ReadonlyThreeTriosModel model) {

    for (int toPlayCard = 0; toPlayCard < model.getCurPlayerHand().size(); toPlayCard++) {
      int count = 0;
      for (int altIndex = 0; altIndex < model.getHand(3 - model.playersTurn()).size();
           altIndex++) {
        int first = addIfFlipped(0, model.numCols() - 1, model, 0,
                model.numCols() - 2, toPlayCard, altIndex);
        int second = addIfFlipped(0, model.numCols() - 1, model, 1,
                model.numCols() - 1, toPlayCard, altIndex);
        count = count + first + second;
      }
      if (count < numThatFlip) {
        numThatFlip = count;
        moveAttempt = new TriosMove(0, model.numCols() - 1, toPlayCard, count);
      }
    }
    return moveAttempt;
  }


  /**
   * Tries the top left corner.
   *
   * @param model the model being passed.
   * @return returns the best trios move possible.
   */
  private TriosMove tryTopLeft(ReadonlyThreeTriosModel model) {
    TriosMove bestMove = new TriosMove(0, 0, 0,
            2 * model.getHand(3 - model.playersTurn()).size());

    for (int toPlayCard = 0; toPlayCard < model.getCurPlayerHand().size(); toPlayCard++) {
      int count = 0;
      for (int altIndex = 0; altIndex < model.getHand(3 - model.playersTurn()).size();
           altIndex++) {
        int first = addIfFlipped(0, 0, model, 0, 1, toPlayCard, altIndex);
        int second = addIfFlipped(0, 0, model, 1, 0, toPlayCard, altIndex);
        count = count + first + second;
      }
      if (count < bestMove.getCount()) {
        bestMove = new TriosMove(0, 0, toPlayCard, count);
      }
    }
    return bestMove;
  }

  /**
   * calls adIfFlipped on the model.
   *
   * @param row        represents the row number.
   * @param col        the col number.
   * @param model      the model being passed.
   * @param altRow     the altRow number.
   * @param altCol     the altCol number.
   * @param toPlayCard the card to play.
   * @param altIndex   the alternate index.
   * @return returns one if flipped.
   */
  private int addIfFlipped(int row, int col, ReadonlyThreeTriosModel model, int altRow, int altCol,
                           int toPlayCard, int altIndex) {
    return model.addIfFlipped(row, col, altRow, altCol, toPlayCard, altIndex);
  }


}
