﻿Overview:
The problem this codebase is trying to solve is regarding how different models can look in the future, and allowing for extensibility with that, as well as extensibility for if Cards are changed in their description or usage, for instance if battles are now for which card is lower instead of higher.
Regarding the forms of extensibility that are envisioned, we see this being relevant to three things: the model, the cards, and players. Our vision for players will be explained more in depth later in this document, but our current implementation of it does not serve extensibility as players are represented by either int 1 or 2. Both the cards and the model have interfaces that allow for future objects of these types to be created in a different way than was currently described and both current versions are explained below in the key components section. High-level assumptions that are made regarding prerequisites for using this code are that the users know the game and understand the rules, as well as create a board and deck in order to start the game either through constructing their own or using our configuration file reader classes to create those objects. Furthermore regarding the configuration file reader classes we made, in the future we can make those more extensible by creating an abstract class that both of them extend and in each would implement a “builder” method to create the specific objects that they are supposed to (as of current that is a card database/deck and a grid, or what we called board).






Quick start:
@Test
public void TestSetUpForREADME() throws FileNotFoundException {
 List<GameCard> deckTest = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
 Board boardTest = new GridReader("ConfigurationFiles/HoleBoardAllCardsReachable")
         .GridBuilder();
 model = new TriosModel();
 model.startGame(boardTest, deckTest);
}




Key Components:
Model: 
There is an interface IModel, which allows for extensibility as future variations of the game can be implemented with different components or rules, but currently the only class that implements said interface is TriosModel which is the representation of the game play as we currently understand, and contains all the following subcomponenets that are explained in more detail below.
        Hand1/Hand2: List of cards that each player can use in their gameplay that are made in startGame
        Deck: List of cards that can be played, and given to the Hand1 and Hand2, and is passed in to startGame.


Card:
Represents a card in the game. Can be of type GameCard (useable card in the game that has values which will be described below, and a unique String name), or BlockedCell, which is a cell that is randomly placed on the board, or through the configuration file, and blocks a user from placing a GameCard in the spot. Also has an owner after it is given to a hand, or when it loses a battle, and can be either int 1 or 2. Before that occurs the owner is  int 0. 
        
Values: Enum representing the potential values that a GameCard’s direction (North, South, East, West) can have, ranging from 1-9, A which has a value of 10. 
        
Board:
Represents the grid in play, and is a list of a list of cards, thus it has rows and columns. When created it either has a null or a BlockedCell in it. During gameplay, players place their own cards in null spots, but cannot place their cards in spots that have


View: 
Currently it is a simple textual rendering of the gamestate as shown in the assignment instructions, but in the future will be a graphical representation of the board and hands. 


Additionally there are two configuration file readers that use a configuration file as given to us in the assignment to create instances of the Board and of a list of the GameCards in play. 


Source Organization:
Everything related to the model and its components such as the Card interfaces and the classes that implement it, and the board, are all in the model directory inside the src directory.


Everything related to the view, will be in the view directory inside the src directory.


Everything related to the controller, which has yet to be implemented is inside the controller directory inside the src directory. 


Our thoughts on future implementation of Player as asked for in the assignment:
Creating an Enum for PlayerType which would have two constants, one being a RegularPlayer, represented by integers, which is essentially how we currently designed this. The other would be a AIPlayer which would have a value of an object that we make to represent an AI player through a separate class that we design. This can be done for any future type of players that we might have to add.