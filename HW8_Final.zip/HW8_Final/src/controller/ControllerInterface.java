package controller;

public interface ControllerInterface {
  /**
   * Ensures card selected is in correct player's hand, cannot select opponent's card.
   * Also ensures it is displayed on the correct view.
   *
   * @param handIndex of card selected.
   */
  public int selectCard(int handIndex, int owner);

  /**
   * feature that needs to be implemented.
   *
   * @param row of where to place card.
   * @param col of where to place card.
   */
  public void placeCard(int row, int col);



  public void playerHasChanged();

  public void refreshView();
}

}
