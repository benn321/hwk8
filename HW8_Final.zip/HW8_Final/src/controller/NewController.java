package controller;

import java.awt.event.ActionListener;

import model.IModel;
import providercode.controller.PlayerActionListener;
import providercode.controller.ThreeTriosController;
import providercode.model.ModelStatusListener;
import providercode.model.Player;
import view.TriosGraphicsFrame;
import view.ViewFrameInterface;

public class NewController implements ModelStatusListener, PlayerActionListener, ControllerInterface {

  private TriosController controller;
  private IModel model;
  private ViewFrameInterface view;

  public NewController(IModel model, int playerNum, TriosGraphicsFrame view) {
    controller = new TriosController(model, playerNum, view);
    this.model = model;
    this.view = view;
  }

  @Override
  public void onCardSelected(int cardIndex) {
    selectCard(cardIndex, model.playersTurn());
  }

  @Override
  public void onCellSelected(int row, int col) {
    placeCard(row, col);
  }

  @Override
  public void onPlayerTurn(Player player) {
    playerHasChanged();
  }

  @Override
  public void onGameOver(Player player) {

  }

  @Override
  public void onInvalidMove(String message) {

  }

  @Override
  public int selectCard(int handIndex, int owner) {
    return 0;
  }

  @Override
  public void placeCard(int row, int col) {

  }

  @Override
  public void playerHasChanged() {

  }

  @Override
  public void refreshView() {
    view.refresh();
  }
}
}
