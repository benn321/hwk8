package controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.BlockedCell;
import model.Board;
import model.Card;

/**
 * Reads grid data from a file and builds a {@code Board} object based on the data.
 * Each line in the file represents a row on the grid, where characters indicate
 * blocked cells or empty cells for card placement.
 */
public class GridReader {

  private final Scanner scanner;

  /**
   * Constructs a {@code GridReader} to read grid data from a specified file.
   *
   * @param fileName the name of the file containing grid data
   * @throws FileNotFoundException if the file cannot be found
   */
  public GridReader(String fileName) throws FileNotFoundException {
    this.scanner = new Scanner(new FileReader(fileName));
  }

  /**
   * Builds a {@code Board} from the file data. Each row in the file represents a row on the
   * grid. 'X' indicates a blocked cell, while 'C' indicates an empty cell for card placement.
   *
   * @return a {@code Board} object based on the grid data read from the file
   */
  public Board gridBuilder() {
    String rowChar;
    List<List<Card>> gridRead = new ArrayList<>();
    rowChar = scanner.next();
    int rowNum = Integer.parseInt(rowChar);

    while (scanner.hasNext()) {
      for (int row = 0; row < rowNum; row++) {
        if (scanner.hasNext()) {
          String line = scanner.nextLine();
          List<Card> rowOfCards = new ArrayList<>();
          for (char c : line.toCharArray()) {
            if (c == 'X') {
              rowOfCards.add(new BlockedCell());
            } else if (c == 'C') {
              rowOfCards.add(null);
            }
          }
          gridRead.add(rowOfCards);
        }
      }
    }

    // Remove the first element if it’s an empty list or incorrectly added row
    if (!gridRead.isEmpty() && gridRead.get(0).isEmpty()) {
      gridRead.remove(0);
    }

    return new Board(gridRead);
  }
}
