﻿NEW READ ME FOR HW7
Overview:
        The main aspects of this assignment were to create a controller for the game, as well as a way for computer players to use the strategies we implemented in the prior assignment in the game. 
        We needed to make sure that the game flow works as expected. To do this we added features for the model so that the model can tell the controller when turns changed. Additionally we needed to ensure that the controller can work with human players that interact with the view, as well as computer players/AI players that use the strategies we designed, and do not interact with the view. 
Quickstart:
public final class ThreeTrios {


 /**
  * main method to test the view.
  * @param args the args passed in.
  * @throws FileNotFoundException if file is not found.
  */
 public static void main(String[] args) throws FileNotFoundException {


   List<GameCard> deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
   Board board5by7 = new GridReader("ConfigurationFiles/3x3NoHoles").gridBuilder();
   TriosModel model = new TriosModel();
   model.startGame(board5by7, deck);
   TriosGraphicsFrame viewPlayer1 = new TriosGraphicsFrame(model);
   TriosGraphicsFrame viewPlayer2 = new TriosGraphicsFrame(model);
   Player human1 = new HumanPlayer(model, 1);
   Player human2 = new HumanPlayer(model, 2);
   Player player1 = new StratOnePlayer(model, 1);
   Player playerStrat1 = new StratOnePlayer(model, 2);
   Player player2 = new StratTwoPlayer(model, 1);
   Player player22 = new StratTwoPlayer(model, 2);
   TriosController controller1 = new TriosController(model, viewPlayer1, player2);
   TriosController controller2 = new TriosController(model, viewPlayer2, player22);
   TriosGraphicsFrame view = new TriosGraphicsFrame(model);
 }
}




Key Components:
Player interface - represents a player, implemented by two strategy player classes (one for each strategy we designed), and one human player class, which essentiatlly just has a number
TriosController - takes in a IModel model, a view, and a player. 
We needed to construct two controllers to start the game, one for each player, as well as two views. 
Controller works with both types of players, human and strategy. 
Source organization:
        Everything is organized as it was before, there were no changes to the src organization for this. 


CHANGES FROM HW6:
        We added a Player interface, that is implemented by human player class, and strategy player classes. That way we can pass in a player and it can either be an “AI” or computer player that automatically chooses moves based on the strategies we designed, or it can be a human player that interacts with the view to play the game. 
        In the model, we also added a method that plays out a full sequence of play (placing a card and battling), in order to be used in the controller. 
        Additionally we added features for the model, to be able to send status updates to the controller.