package cs3500.threetrios.view.src.view;

import java.io.IOException;

/**
 * Behaviors needed for the view of the ThreeTrios
 * implementation that transmit information to the user.
 */
public interface BasicThreeTriosView {

  /**
   * Renders the model in some way (textual, graphical, etc.).
   * @throws IllegalStateException if game has not started
   * @throws IllegalStateException if render fails for some reason
   */
  void render() throws IOException;
}
