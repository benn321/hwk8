package cs3500.threetrios.view.src.view;

/**
 * Interface that represents the view for the ThreeTrios.
 */
public interface Swing {

  /**
   * Refreshes the view with the updated model.
   */
  void refreshView();

  /**
   * Initializes the components of the view.
   */
  void initializeComponents();

  /**
   * Updates the selection state of a card.
   */
  void updateSelectedCard(boolean isRed, int index, boolean selected);

  /**
   * Adds the player action listener to the view to keep track of the human player's selections.
   * @param listener action listeners
   */
  void addPlayerActionListener(PlayerActionListener listener);

  /**
   * Notifies the listeners when a card is selected.
   * @param cardIndex index of selected card
   */
  void notifyCardSelected(int cardIndex);

  /**
   * Notifies the listeners when a cell is selected.
   * @param row row index of selected cell
   * @param col col index of selected cell
   */
  void notifyCellSelected(int row, int col);
}
