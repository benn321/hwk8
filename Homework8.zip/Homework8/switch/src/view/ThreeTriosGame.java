package cs3500.threetrios.view.src.view;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;

import cs3500.threetrios.controller.ThreeTriosControllerClass;
import cs3500.threetrios.view.src.model.Card;
import cs3500.threetrios.model.Cell;
import cs3500.threetrios.model.CellValue;
import cs3500.threetrios.model.PlayingCard;
import cs3500.threetrios.view.src.model.ThreeTrios;
import cs3500.threetrios.model.ThreeTriosModel;
import cs3500.threetrios.model.Value;
import cs3500.threetrios.player.AIPlayer;
import cs3500.threetrios.player.ChooseLessLikelyToBeFlippedStrategy;
import cs3500.threetrios.player.CornerStrategy;
import cs3500.threetrios.player.DisruptOpponentStrategy;
import cs3500.threetrios.player.FirstAvailableOpeningStrategy;
import cs3500.threetrios.player.FlipAsManyPossibleStrategy;
import cs3500.threetrios.player.HumanPlayer;
import cs3500.threetrios.view.src.model.Player;

/**
 * Class to run the game.
 */
public final class ThreeTriosGame {
  /**
   * Main method to run the game.
   * @param args arguments
   */
  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
      try {
        JFrame selectionFrame = new JFrame("Game Setup");
        selectionFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JFrame frame1 = new JFrame("Three Trios Game - Player 1");
        JFrame frame2 = new JFrame("Three Trios Game - Player 2");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Cell[][] board = selectAndLoadBoard(selectionFrame);
        if (board == null) {
          System.exit(0);
        }

        List<Card> cards = selectAndLoadCards(selectionFrame);
        if (cards == null) {
          System.exit(0);
        }

        ThreeTrios model = new ThreeTriosModel();

        Player player1 = choosePlayer(frame1, model);
        Player player2 = choosePlayer(frame2, model);

        model.startGame(cards, board, true, player1, player2);

        ThreeTriosSwing viewPlayer1 = new ThreeTriosSwing(model);
        ThreeTriosSwing viewPlayer2 = new ThreeTriosSwing(model);

        frame1.add(viewPlayer1);
        frame2.add(viewPlayer2);
        frame1.pack();
        frame2.pack();

        frame1.setLocation(50, 100);
        frame2.setLocation(frame1.getWidth() + 100, 100);

        ThreeTriosControllerClass controller1 = new ThreeTriosControllerClass(model,
                viewPlayer1, player1);
        ThreeTriosControllerClass controller2 = new ThreeTriosControllerClass(model,
                viewPlayer2, player2);

        frame1.setVisible(true);
        frame2.setVisible(true);

        selectionFrame.dispose();

      } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null,
                "Error starting game: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        System.exit(1);
      }
    });
  }

  private static Player choosePlayer(JFrame frame, ThreeTrios model) {
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    JLabel label = new JLabel("Select player type: ");
    panel.add(label);

    JRadioButton human = new JRadioButton("Human");
    JRadioButton ai1 = new JRadioButton("AI - Strategy1");
    JRadioButton ai2 = new JRadioButton("AI - Strategy2");
    JRadioButton ai3 = new JRadioButton("AI - Strategy3");
    JRadioButton ai4 = new JRadioButton("AI - Strategy4");
    JRadioButton ai5 = new JRadioButton("AI - Strategy5");

    ButtonGroup group = new ButtonGroup();
    group.add(human);
    group.add(ai1);
    group.add(ai2);
    group.add(ai3);
    group.add(ai4);
    group.add(ai5);

    panel.add(human);
    panel.add(ai1);
    panel.add(ai2);
    panel.add(ai3);
    panel.add(ai4);
    panel.add(ai5);

    int result = JOptionPane.showConfirmDialog(frame, panel, "Choose player type",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (result == JOptionPane.OK_OPTION) {
      if (human.isSelected()) {
        return new HumanPlayer();
      } else if (ai1.isSelected()) {
        return new AIPlayer(new FlipAsManyPossibleStrategy(), model);
      } else if (ai2.isSelected()) {
        return new AIPlayer(new CornerStrategy(), model);
      } else if (ai3.isSelected()) {
        return new AIPlayer(new FirstAvailableOpeningStrategy(), model);
      } else if (ai4.isSelected()) {
        return new AIPlayer(new ChooseLessLikelyToBeFlippedStrategy(), model);
      } else if (ai5.isSelected()) {
        return new AIPlayer(new DisruptOpponentStrategy(), model);
      }
    }
    System.exit(0);
    return null;
  }

  private static Cell[][] selectAndLoadBoard(JFrame frame) throws IOException {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Select Board Layout File");

    int result = fileChooser.showOpenDialog(frame);
    if (result == JFileChooser.APPROVE_OPTION) {
      return loadBoardFromFile(fileChooser.getSelectedFile().getAbsolutePath());
    }
    return null;
  }

  private static Cell[][] loadBoardFromFile(String filename) throws IOException {
    try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
      String dimensionsLine = reader.readLine();
      if (dimensionsLine == null) {
        throw new IllegalArgumentException("Board file is empty");
      }

      String[] dimensions = dimensionsLine.trim().split("\\s+");
      if (dimensions.length != 2) {
        throw new IllegalArgumentException("First line must contain two numbers for dimensions");
      }
      int rows;
      int cols;
      try {
        rows = Integer.parseInt(dimensions[0]);
        cols = Integer.parseInt(dimensions[1]);
      } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Invalid dimensions format");
      }
      if (rows <= 0 || cols <= 0) {
        throw new IllegalArgumentException("Dimensions must be positive numbers");
      }

      Cell[][] board = new Cell[rows][cols];

      for (int row = 0; row < rows; row++) {
        String line = reader.readLine();
        if (line == null) {
          throw new IllegalArgumentException("Board file has fewer rows than specified");
        }

        line = line.trim();
        if (line.length() != cols) {
          throw new IllegalArgumentException(
                  "Row " + (row + 1) + " has incorrect length. " +
                          "Expected " + cols + " but got " + line.length());
        }

        for (int col = 0; col < cols; col++) {
          char cellType = line.charAt(col);
          board[row][col] = parseBoardCell(cellType);
        }
      }

      if (reader.readLine() != null) {
        throw new IllegalArgumentException("Board file has more rows than specified");
      }

      return board;
    }
  }

  private static Cell parseBoardCell(char cellType) {
    switch (cellType) {
      case 'C':
        return new Cell(CellValue.EMPTY);
      case 'X':
        return new Cell(CellValue.HOLE);
      default:
        throw new IllegalArgumentException("Invalid cell type: " + cellType +
                ". Must be 'C' for playable cells or 'X' for holes");
    }
  }

  private static List<Card> selectAndLoadCards(JFrame frame) throws IOException {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Select Cards File");

    int result = fileChooser.showOpenDialog(frame);
    if (result == JFileChooser.APPROVE_OPTION) {
      return loadCardsFromFile(fileChooser.getSelectedFile().getAbsolutePath());
    }
    return null;
  }

  private static List<Card> loadCardsFromFile(String filename) throws IOException {
    List<Card> cards = new ArrayList<>();

    try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
      String line;
      while ((line = reader.readLine()) != null) {
        line = line.trim();
        if (!line.isEmpty() && !line.startsWith("#")) {
          try {
            Card card = parseCardFile(line);
            cards.add(card);
          } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid card data in line: "
                    + line + "\n" + e.getMessage());
          }
        }
      }
    }

    if (cards.isEmpty()) {
      throw new IllegalArgumentException("No valid cards found in file");
    }

    return cards;
  }

  private static Card parseCardFile(String cardData) {
    try {
      String[] parts = cardData.split("\\s+");
      if (parts.length != 5) {
        throw new IllegalArgumentException(
                "Each card must have a name and 4 values (got " + parts.length + " parts)");
      }

      String name = parts[0];
      Value north = Value.fromInt(parts[1]);
      Value south = Value.fromInt(parts[2]);
      Value east = Value.fromInt(parts[3]);
      Value west = Value.fromInt(parts[4]);

      return new PlayingCard(name, north, south, east, west);
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Card values must be numbers between 1 and 10");
    }
  }

}
