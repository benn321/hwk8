package cs3500.threetrios.view.src.model;

import cs3500.threetrios.view.src.view.PlayerActionListener;
import cs3500.threetrios.model.ThreeTriosColor;

/**
 * An interface that represents the types of players that can interact with the game.
 */
public interface Player {

  /**
   * Places the chosen card at the chosen cell.
   */
  void placeCard();

  /**
   * Sets the player's color, so it aligns with the game play.
   * @param color color to set it to
   */
  void setColor(ThreeTriosColor color);

  /**
   * Returns the color of the player.
   * @return color
   */
  ThreeTriosColor getColor();

  /**
   * Adds the given PlayerActionListener to the player.
   * @param listener action listener
   */
  void addPlayerActionListener(PlayerActionListener listener);
}