package cs3500.threetrios.view.src.model;

import java.util.List;

/**
 * Interface that represents the ThreeTrios game.
 * Will extend the original ReadOnlyThreeTriosModel, with actual functions for the game.
 */
public interface ThreeTrios extends ReadOnlyThreeTriosModel {

  /**
   * Starts the given with the given parameters.
   * @param cards cards to be played with
   * @param board game board
   * @param shuffle whether to shuffle the cards or not before distributing the cards
   * @param player1 player that goes first -- Red Player
   * @param player2 player that goes second -- Blue Player
   */
  void startGame(List<Card> cards, Cell[][] board, boolean shuffle, Player player1, Player player2);

  /**
   * Places the card the board for the current player.
   * @param row row index to place card
   * @param col col index to place card
   * @param cardIndex card index to be placed
   */
  void placeCard(int row, int col, int cardIndex);

  /**
   * Adds the given listener to the model, to keep track of game.
   * @param modelStatusListener listener
   */
  void addModelStatusListener(ModelStatusListener modelStatusListener);
}
