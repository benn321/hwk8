package cs3500.threetrios.view.src.model;

/**
 * Interface that serves as a listener between the model and the view.
 */
public interface ModelStatusListener {

  /**
   * What the view to do when it is the given player's turn.
   * @param player player
   */
  void onPlayerTurn(Player player);

  /**
   * What the view needs to do when the game is over.
   * @param player player
   */
  void onGameOver(Player player);

  /**
   * What the view needs to do when the user makes an invalid move.
   * @param message description of invalid move
   */
  void onInvalidMove(String message);
}
