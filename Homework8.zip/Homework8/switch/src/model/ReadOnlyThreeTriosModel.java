package cs3500.threetrios.view.src.model;

import java.util.List;

/**
 * Interface that represents the model for the game.
 * It is ReadOnly to the model is not accidentally changed.
 */
public interface ReadOnlyThreeTriosModel {

  /**
   * Returns a boolean if the game has started or not.
   *
   * @return true if the game has started, false if it hasn't
   */
  boolean isGameStarted();

  /**
   * Returns a boolean that tells the user if the game is over or not.
   *
   * @return true if the game is over, false if not
   */
  boolean isGameOver();

  /**
   * Returns a boolean that depicts whether there was a winner (the game did not end in a tie).
   *
   * @return true if there was a winner
   */
  boolean isGameWon();

  /**
   * Returns the current player of the game.
   *
   * @return current player
   */
  Player getPlayer();

  /**
   * Returns the red player's hand.
   * @return a copy of the player's hand
   */
  List<Card> getRedPlayerHand();

  /**
   * Returns the blue player's hand.
   * @return a copy of the player's hand
   */
  List<Card> getBluePlayerHand();

  /**
   * Returns the number of rows on the board.
   * @return number of rows
   */
  int getNumOfRows();

  /**
   * Returns the number of columns on the board.
   * @return number of columns
   */
  int getNumOfColumns();

  /**
   * Returns the state of the wanted cell -- Empty, HasCard, Hole.
   * @param row 0-based index for the cell's row
   * @param column 0-based index for the cell's column
   * @return the CellValue of the given cell
   * @throws IllegalArgumentException if row or column values are not valid
   */
  CellValue getCellValue(int row, int column);

  int redScore();

  /**
   * Returns the number of cards that are blue at the moment it is called.
   * @return number of blue cards on the board and in the blue player's hand
   */
  int blueScore();

  /**
   * Returns a copy of the current game board.
   * @return the current game board
   */
  Cell[][] getBoard();

  /**
   * Returns the winning player.
   * @return winning player color
   * @throws IllegalStateException if game has not started
   * @throws IllegalStateException if game is not over
   * @throws IllegalStateException if the game ended in a tie
   */
  Player getWinner();

  /**
   * Returns the card that is at the given row and col on the board.
   * @param row row index for the board
   * @param col col index for the board
   * @return card at the row and col index
   */
  Card getCard(int row, int col);

  /**
   * Returns the cell value at the given row and col on the board.
   * @param row row index
   * @param col col index
   * @return CellValue
   */
  CellValue getCell(int row, int col);

  /**
   * Returns the number of cards flipped if the card is placed.
   * @param row row index for the card placement
   * @param col col index for the card placement
   * @param cardIndex card index of the player's hand
   * @param player color that represents the player
   * @return number of cards flipped
   */
  int numFlipped(int row, int col, int cardIndex, ThreeTriosColor player);
}
