import org.junit.Test;

import java.io.FileNotFoundException;

import controller.CardDataBaseReader;
import controller.GridReader;

import static org.junit.Assert.assertEquals;

/**
 * tests the config files and readers for those files.
 */
public class ConfigFileTests {

  /**
   *Tests that the reader correctly constructs a board.
   */
  @Test
  public void gridReaderTest() {
    String filename = "ConfigurationFiles/basicGridConfigForTest";
    GridReader testGridReader;
    try {
      testGridReader = new GridReader(filename);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    }
    assertEquals(testGridReader.gridBuilder().toString(),
            "[null, null,  ,  ,  ,  , null]\n" +
                    "[null,  , null,  ,  ,  , null]\n" +
                    "[null,  ,  , null,  ,  , null]\n" +
                    "[null,  ,  ,  , null,  , null]\n" +
                    "[null,  ,  ,  ,  , null, null]\n");
  }

  /**
   *reads in the card file and ensures it is read the correct way.
   */
  @Test
  public void CardDatabaseReaderTest() {
    String filename = "ConfigurationFiles/CardFile";
    CardDataBaseReader testCardreader;
    try {
      testCardreader = new CardDataBaseReader(filename);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    }
    assertEquals(testCardreader.deckBuilder().toString(),
            "[fijf 4 9 8 2, fjfo 9 7 1 9, nvor 9 A 3 A, bvoefon 9 5 6 3, fif 4 9 8 2, " +
                    "ffo 9 7 1 9, vor 9 A 3 A, bvoen 9 5 6 3, ff 4 9 8 2, fo 9 7 1 9, " +
                    "nvr 9 A 3 A, " +
                    "bvon 9 5 6 3, fierjf 4 9 8 2, fjgro 9 7 1 9, nvbdor 9 A 3 A, " +
                    "bvowefon 9 5 6 3," +
                    " fijfsdf 4 9 8 2, fjfrto 9 7 1 9, nvowsr 9 A 3 A, bvoedgsfon 9 5 6 3, " +
                    "fijxf 4 9 8 2, fjfiro 9 7 1 9, nvoyr 9 A 3 A, bnooefon 9 5 6 3, " +
                    "ijrf 4 9 8 2, fslo 9 7 1 9, nvsr 9 A 3 A]");
  }
}
