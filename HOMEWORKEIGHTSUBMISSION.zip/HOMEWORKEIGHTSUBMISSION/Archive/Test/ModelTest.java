import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.BlockedCell;
import model.Board;
import model.Card;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.TriosModel;
import view.SimpleStringView;
import view.TrioStringView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * tests the models and its methods for functionality and throwing errors.
 */
public class ModelTest {

  private Board board5by7;
  private Board boardNoHoles;
  private Board allCardsReachable;
  private Board twoUnreachable;
  private Board emptyBoard;
  private TriosModel model;
  private List<GameCard> deck = new ArrayList<>();
  private List<GameCard> deckSize16 = new ArrayList<>();
  private SimpleStringView view;

  @Before
  public void setUp() throws FileNotFoundException {
    deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    deckSize16 = new CardDataBaseReader("ConfigurationFiles/CardFileSize16").deckBuilder();
    board5by7 = new GridReader("ConfigurationFiles/basicGridConfigForTest").gridBuilder();
    boardNoHoles = new GridReader("ConfigurationFiles/NoHoleBoard").gridBuilder();
    allCardsReachable = new GridReader("ConfigurationFiles/HoleBoardAllCardsReachable")
            .gridBuilder();
    twoUnreachable = new GridReader("ConfigurationFiles/BoardWithTwoUnreachableGroups")
            .gridBuilder();
    emptyBoard = new Board();
    Random randForShuffle = new Random(1);
    model = new TriosModel(randForShuffle);
    Appendable ap = new StringBuilder();
    view = new TrioStringView(model, ap);
  }


  /**
   * Tests that startGame throws an exception when the game is over.
   * empty board simulates that as there are no nulls and the game is over when there are no more
   * nulls.
   */
  @Test(expected = IllegalStateException.class)
  public void testStartGameGameOverException() {
    model.startGame(emptyBoard, deckSize16);
  }

  /**
   * tests that an IllegalArgumentException is thrown when an invalid deck is passed in.
   * Deck is invalid as it is too small for the board size.
   *
   * @throws FileNotFoundException if file not found.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameWithInvalidDeck() throws FileNotFoundException {
    List<GameCard> deckTest =
            new CardDataBaseReader("ConfigurationFiles/CardFileSize16").deckBuilder();
    model.startGame(boardNoHoles, deckTest); // This should throw IllegalArgumentException
  }

  /**
   * Tests that an IllegalStateException is thrown when startGame is used after the game has
   * already started.
   */
  @Test(expected = IllegalStateException.class)
  public void testStartGameTwice() {
    model.startGame(twoUnreachable, deck);
    model.startGame(twoUnreachable, deck); // This should throw IllegalStateException
  }

  /**
   * Tests that a valid card placement works.
   */
  @Test
  public void testValidCardPlacement() {
    Card firstCard = deck.get(1);
    model.startGame(board5by7, deck);
    model.placeCard(0, 0, 0);
    assertEquals(firstCard, model.getCardAt(0, 0));
  }


  /**
   * Testing if placing a card on a taken cell throws an IllegalArgumentException.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCardPlacementOnTakenCell() {
    model.startGame(allCardsReachable, deck);
    assertFalse(model.isGameWon());
    model.placeCard(1, 2, 0);
    assertFalse(model.isGameWon());
    model.placeCard(1, 2, 0);
  }

  /**
   * Tests if placing a card out of bounds (col) throws an IllegalArgument Exception.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCardPlacementOutOfBoundsCol() {
    model.startGame(board5by7, deck);
    assertFalse(model.isGameWon());
    model.placeCard(1, 7, 0);
  }

  /**
   * Tests if placing a card out of bounds (rows) throws an IllegalArgument Exception.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCardPlacementOutOfBoundsRow() {
    model.startGame(board5by7, deck);
    assertFalse(model.isGameWon());
    model.placeCard(5, 2, 0);
  }


  /**
   * Testing for game over exception.
   * Added a board with one available spot, once that spot is taken, game is over.
   * Cannot place another card afterwards.
   */
  @Test(expected = IllegalStateException.class)
  public void testCardPlacementGameOver() {
    List<Card> oneCell = new ArrayList<>();
    oneCell.add(null);
    List listOfOneCard = new ArrayList<>();
    listOfOneCard.add(oneCell);
    Board oneCellBoard = new Board(listOfOneCard);
    model.startGame(oneCellBoard, deck);
    model.placeCard(0, 0, 0);
    assertTrue(model.isGameWon());
    assertEquals(model.getWinner(), 0);
    model.placeCard(0, 0, 0);
  }


  /**
   * Tests that an IllegalArgumentException is thrown when battle is called on a null.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBattleNullCell() {
    List<Card> oneCell = new ArrayList<>();
    oneCell.add(null);
    List listOfOneCard = new ArrayList<>();
    listOfOneCard.add(oneCell);
    Board oneCellBoard = new Board(listOfOneCard);
    model.startGame(oneCellBoard, deck);
    model.battle(0, 0);
  }

  /**
   * Tests that an IllegalArgumentException is thrown when battle is called on a BlockedCell.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testBattleBlockedCell() {
    List<Card> twoCell = new ArrayList<>();
    BlockedCell blockedCell = new BlockedCell();
    twoCell.add(blockedCell);
    twoCell.add(null);
    List listOfOneCard = new ArrayList<>();
    listOfOneCard.add(twoCell);
    Board oneCellBoard = new Board(listOfOneCard);
    model.startGame(oneCellBoard, deck);
    model.battle(0, 0);
  }

  /**
   * Tests chain ownership change.
   * Also checks playersTurn returns correct player.
   *
   * @throws IOException if exception is thrown.
   */
  @Test
  public void testBattleChangesOwnership() throws IOException {
    model.startGame(boardNoHoles, deck);
    assertEquals(model.playersTurn(), 1);
    model.placeCard(0, 0, 0);
    assertEquals(model.playersTurn(), 2);
    model.battle(0, 0);
    model.placeCard(0, 2, 0);
    assertEquals(model.playersTurn(), 1);
    model.battle(0, 2);
    model.placeCard(1, 0, 3);
    assertEquals(model.playersTurn(), 2);
    model.battle(1, 0);
    model.placeCard(0, 1, 0);
    assertEquals(model.playersTurn(), 1);
    model.battle(0, 1);
    view.render();
    Assert.assertEquals(model.getCardAt(1, 0).getOwner(), 2);
  }

  /**
   * Tests that the correct winner is displayed when getWinner called.
   */
  @Test
  public void testGetWinner2() {
    List<Card> oneCell = new ArrayList<>();
    oneCell.add(null);
    List listOfOneCard = new ArrayList<>();
    listOfOneCard.add(oneCell);
    Board oneCellBoard = new Board(listOfOneCard);
    model.startGame(oneCellBoard, deck);
    model.placeCard(0, 0, 0);
    assertTrue(model.isGameWon());
    assertEquals(model.getWinner(), 0);
  }

  /**
   * Tests that an IllegalStateException is thrown when getWinner is called before game is over.
   */
  @Test(expected = IllegalStateException.class)
  public void testGetWinnerGameIsNotOver() {
    List<Card> oneCell = new ArrayList<>();
    oneCell.add(null);
    List listOfOneCard = new ArrayList<>();
    listOfOneCard.add(oneCell);
    Board oneCellBoard = new Board(listOfOneCard);
    model.startGame(oneCellBoard, deck);
    assertFalse(model.isGameWon());
    model.getWinner();
  }

  /**
   * tests that numRows and numCols correctly returns rows and columns.
   */
  @Test
  public void testNumRowNumCols() {
    model.startGame(boardNoHoles, deck);
    assertEquals(model.numRows(), 5);
    assertEquals(model.numCols(), 5);
  }

  /**
   * tests that the correct hand is returned for getCurrPlayerHand().
   */
  @Test
  public void testGetCurrPlayerHand() {
    model.startGame(boardNoHoles, deck);

    List<Card> player2Hand = new ArrayList<>();
    Assert.assertEquals(model.playersTurn(), 1);
    Assert.assertEquals(model.getCurPlayerHand().toString(), "[fjfo 9 7 1 9, " +
            "fjgro 9 7 1 9, " +
            "bvon 9 5 6 3, nvowsr 9 A 3 A, fijfsdf 4 9 8 2, nvsr 9 A 3 A, fierjf 4 9 8 2, " +
            "bvoen 9 5 6 3, bvoedgsfon 9 5 6 3, bnooefon 9 5 6 3, nvbdor 9 A 3 A, fslo 9 7 1 9," +
            " nvoyr 9 A 3 A]");
    model.placeCard(0, 0, 0);
    Assert.assertEquals(model.playersTurn(), 2);
    Assert.assertEquals(model.getCurPlayerHand().toString(), "[fijxf 4 9 8 2, " +
            "fif 4 9 8 2, " +
            "ff 4 9 8 2, bvoefon 9 5 6 3, bvowefon 9 5 6 3, fjfrto 9 7 1 9, ffo 9 7 1 9, " +
            "fjfiro 9 7 1 9, nvr 9 A 3 A, vor 9 A 3 A, nvor 9 A 3 A, fo 9 7 1 9, fijf 4 9 8 2]");
  }


}

