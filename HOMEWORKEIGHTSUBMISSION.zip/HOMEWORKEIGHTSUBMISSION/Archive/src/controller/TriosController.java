package controller;


import model.HumanPlayer;
import model.IModel;
import model.ModelFeatures;
import model.Player;
import view.TriosFeatures;
import view.TriosGraphicsFrame;

/**
 * Representation of a controller.
 * implements the view and model features so each aspect of the game is loosely coupled.
 */
public class TriosController implements TriosFeatures, ModelFeatures {
  private int selectedCard;
  private IModel model;
  private int playerNum;
  private TriosGraphicsFrame view;
  private Player player;

  /**
   * constructor for controller if just using player nums.
   */
  public TriosController(IModel model, int playerNum, TriosGraphicsFrame view) {
    this.selectedCard = -1;
    this.model = model;
    this.playerNum = playerNum;
    this.view = view;

    if (model != null || view != null) {
      view.setFeatures(this);
      view.setVisible(true);
      model.setFeatures(this, playerNum);
    }

  }

  /**
   * constructor for controller.
   */
  public TriosController(IModel model, TriosGraphicsFrame view, Player player) {
    this.selectedCard = -1;
    this.model = model;
    this.playerNum = player.getNum();
    this.view = view;
    if (player instanceof HumanPlayer) {
      this.player = null;
    } else {
      this.player = player;
      this.player.setFeatures(this);
    }
    if (model != null || view != null) {
      view.setFeatures(this);
      view.setVisible(true);
      model.setFeatures(this, playerNum);
    }
    this.playerHasChanged();
  }


  /**
   * Ensures card selected is in correct player's hand, cannot select opponent's card.
   * Also ensures it is displayed on the correct view.
   *
   * @param handIndex of card selected.
   */
  @Override
  public int selectCard(int handIndex, int owner) {
    this.view.refresh();
    if (model.playersTurn() == playerNum && model.playersTurn() == owner) {
      if (selectedCard == handIndex) {
        selectedCard = -1;
        return selectedCard;
      } else {
        selectedCard = handIndex;
        return selectedCard;
      }
    }
    view.displayMessage("can't select card from this hand");
    return -1;
  }

  /**
   * feature that needs to be implemented.
   *
   * @param row of where to place card.
   * @param col of where to place card.
   */
  @Override
  public void placeCard(int row, int col) {
    if (selectedCard == -1) {
      view.displayMessage("no card selected.");
      // display an error to user saying no card selected
    } else {
      try {
        model.oneSequence(row, col, selectedCard);
        selectedCard = -1;
      } catch (IllegalArgumentException e) {
        view.displayMessage("can't play here");
      }
    }
    this.view.refresh();
  }


  @Override
  public void playerHasChanged() {

    if (model.isGameWon() && model.getWinner() != 0) {
      view.displayMessage("player " + model.getWinner() + " won with a score of: " +
              (model.getHand(model.getWinner()).size() + model.getScore(model.getWinner())));
    } else if (model.isGameWon()) {
      view.displayMessage("the game ended in a tie");
    } else if (player != null) {
      player.makeAMove();
    } else if (playerNum == 1) {
      view.displayMessage("it is player ones turn");
    } else if (playerNum == 2) {
      view.displayMessage("it is player twos turn");
    }
  }

  @Override
  public void refreshView() {
    this.view.refresh();
  }
}
