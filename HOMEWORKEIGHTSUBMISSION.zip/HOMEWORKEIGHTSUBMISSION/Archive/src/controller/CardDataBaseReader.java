package controller;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.GameCard;
import model.Values;

/**
 * Reads card data from a file and builds a deck of {@code GameCard} objects based on the data.
 * Each line in the file should represent a card with a unique name and four attack values.
 */
public class CardDataBaseReader {
  private final Scanner scanner;

  /**
   * Constructs a {@code CardDataBaseReader} to read card data from a specified file.
   *
   * @param fileName the name of the file containing card data
   * @throws FileNotFoundException if the file cannot be found
   */
  public CardDataBaseReader(String fileName) throws FileNotFoundException {
    this.scanner = new Scanner(new FileReader(fileName));
  }

  /**
   * Builds a list of {@code GameCard} objects from the file data. Ensures each card name is unique.
   *
   * @return a list of {@code GameCard} objects representing the deck
   * @throws IllegalArgumentException if a duplicate card name is found
   */
  public List<GameCard> deckBuilder() {
    List<GameCard> listOfCards = new ArrayList<>();
    List<String> nameList = new ArrayList<>();

    while (scanner.hasNextLine()) {
      String name;
      Values n;
      Values s;
      Values e;
      Values w;

      name = scanner.next();
      if (nameList.contains(name)) {
        throw new IllegalArgumentException("Duplicate card name: " + name);
      }
      nameList.add(name);
      n = stringToValue(scanner.next());
      s = stringToValue(scanner.next());
      e = stringToValue(scanner.next());
      w = stringToValue(scanner.next());

      GameCard cardToAdd = new GameCard(name, n, e, s, w);
      listOfCards.add(cardToAdd);
    }
    return listOfCards;
  }

  /**
   * Converts a string representation of a value to a {@code Values} enum.
   *
   * @param s the string to convert
   * @return the corresponding {@code Values} enum
   * @throws IllegalArgumentException if the string does not match a valid value
   */
  public Values stringToValue(String s) {
    switch (s) {
      case "1": return Values.ONE;
      case "2": return Values.TWO;
      case "3": return Values.THREE;
      case "4": return Values.FOUR;
      case "5": return Values.FIVE;
      case "6": return Values.SIX;
      case "7": return Values.SEVEN;
      case "8": return Values.EIGHT;
      case "9": return Values.NINE;
      case "A": return Values.A;
      default: throw new IllegalArgumentException("Invalid value: " + s);
    }
  }
}
