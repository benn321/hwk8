package controller;

import java.util.ArrayList;
import java.util.List;

import model.IModel;
import model.ModelFeatures;
import model.Player;
import view.TriosFeatures;
import view.TriosGraphicsFrame;

/**
 * Mock controller used to test the function of the actual controller.
 */
public class MockController extends TriosController implements TriosFeatures, ModelFeatures {
  List<String> list = new ArrayList<>();
  private IModel model;
  public List<Integer> selectedCards; // public for testing since this class is not used for playing
  public List<String> cardsPlaced; // public so easy access for testing as this class is never used


  /**
   * constructor for the mock controller which calls super and inizialized the lists.
   * @param model the model use for the game.
   * @param view the view used for the game.
   * @param player the Player used in this instance of the controller.
   */
  public MockController(IModel model, TriosGraphicsFrame view, Player player) {
    super(model, player.getNum(), view);
    this.model = model;
    cardsPlaced = new ArrayList<>();
    selectedCards = new ArrayList<>();
  }


  public List<String> getList() {
    return this.list;
  }


  @Override
  public void playerHasChanged() {
    this.list.add(Integer.toString(this.model.playersTurn()) + " ");
    super.playerHasChanged();
  }

  @Override
  public void refreshView() {
    super.refreshView();
  }

  @Override
  public int selectCard(int handIndex, int owner) {
    selectedCards.add(handIndex);
    selectedCards.add(owner);
    return super.selectCard(handIndex, owner);
  }

  @Override
  public void placeCard(int row, int col) {
    cardsPlaced.add(Integer.toString(row) + "," + Integer.toString(col));
    super.placeCard(row, col);
  }
}
