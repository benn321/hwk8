package model;

import java.util.Random;

/**
 * Represents a GameCard that can be played on a board. Each GameCard has a name, an owner, and
 * four attack values (north, south, east, and west) that determine its strength in battles with
 * other cards on the board.
 */
public class GameCard implements Card {
  private String name;
  private int owner;
  private final Values west;
  private final Values east;
  private final Values north;
  private final Values south;
  private final Random rand;

  /**
   * Constructs a GameCard with specified name and attack values.
   *
   * @param name  the name of the card
   * @param west  the attack value on the west side of the card
   * @param east  the attack value on the east side of the card
   * @param north the attack value on the north side of the card
   * @param south the attack value on the south side of the card
   */
  public GameCard(String name, Values west, Values east, Values north, Values south) {
    this.name = name;
    this.west = west;
    this.east = east;
    this.north = north;
    this.south = south;
    this.rand = new Random();
    this.owner = 0;
  }

  /**
   * Constructs a new GameCard by copying the properties of an existing GameCard.
   * @param gameCard the GameCard to copy.
   */
  public GameCard(GameCard gameCard) {
    this.name = gameCard.name;
    this.west = gameCard.west;
    this.east = gameCard.east;
    this.north = gameCard.north;
    this.south = gameCard.south;
    this.rand = new Random();
    this.owner = gameCard.owner;
  }

  /**
   * Constructs a GameCard with a specified name and a random attack value generator.
   * @param name the name of the card.
   * @param rand a Random instance for generating attack values.
   */
  public GameCard(String name, Random rand) {
    this.name = name;
    this.rand = rand;
    Values[] numbers = Values.values();
    this.west = numbers[rand.nextInt(numbers.length)];
    this.east = numbers[rand.nextInt(numbers.length)];
    this.north = numbers[rand.nextInt(numbers.length)];
    this.south = numbers[rand.nextInt(numbers.length)];
    this.owner = 0;
  }

  /**
   * Constructs a GameCard with a specified name and random attack values.
   * @param name the name of the card.
   */
  public GameCard(String name) {
    Values[] numbers = Values.values();
    this.rand = new Random();
    this.west = numbers[rand.nextInt(numbers.length)];
    this.east = numbers[rand.nextInt(numbers.length)];
    this.north = numbers[rand.nextInt(numbers.length)];
    this.south = numbers[rand.nextInt(numbers.length)];
    this.name = name;
    this.owner = 0;
  }

  /**
   * Returns a string representation of this GameCard, including its name and attack values.
   * @return a string representation of the GameCard.
   */
  public String toString() {
    return name + " "
            + north.toString() + " "
            + south.toString() + " "
            + east.toString() + " "
            + west.toString();
  }

  /**
   * Changes the owner of the GameCard.
   * @param i the int of the owner, either 1 or 2.
   */
  void changeOwner(int i) {
    this.owner = i;
  }

  /**
   * Conducts a battle with a card to the north. If this card's north value is higher,
   * changes the ownership of the opponent card.
   * @param tile the GameCard to battle with.
   * @return true if this card wins the battle, false otherwise.
   */
  boolean battleNorth(GameCard tile) {
    if (north.value > tile.south.value && this.owner != tile.owner) {
      tile.changeOwner(this.owner);
      return true;
    }
    return false;
  }

  /**
   * Conducts a battle with a card to the south. If this card's south value is higher,
   * changes the ownership of the opponent card.
   * @param tile the GameCard to battle with.
   * @return true if this card wins the battle, false otherwise.
   */
  boolean battleSouth(GameCard tile) {
    if (south.value > tile.north.value && this.owner != tile.owner) {
      tile.changeOwner(this.owner);
      return true;
    }
    return false;
  }

  /**
   * Conducts a battle with a card to the east. If this card's east value is higher,
   * changes the ownership of the opponent card.
   * @param tile the GameCard to battle with.
   * @return true if this card wins the battle, false otherwise.
   */
  boolean battleEast(GameCard tile) {
    if (east.value > tile.west.value && this.owner != tile.owner) {
      tile.changeOwner(this.owner);
      return true;
    }
    return false;
  }

  /**
   * Conducts a battle with a card to the west. If this card's west value is higher,
   * changes the ownership of the opponent card.
   * @param tile the GameCard to battle with.
   * @return true if this card wins the battle, false otherwise.
   */
  boolean battleWest(GameCard tile) {
    if (west.value > tile.east.value && this.owner != tile.owner) {
      tile.changeOwner(this.owner);
      return true;
    }
    return false;
  }

  /**
   * Returns the int of the owner of this GameCard.
   * @return the int of the owner.
   */
  public int getOwner() {
    return owner;
  }

  /**
   * Returns the name of this GameCard.
   * @return the name of the GameCard.
   */
  public String getName() {
    return this.name;
  }


  public Values getWest() {
    return this.west;
  }


  public Values getEast() {
    return this.east;
  }


  public Values getNorth() {
    return this.north;
  }


  public Values getSouth() {
    return this.south;
  }
}
