package model;

/**
 * Representation of interface that unifies the automatic moves (strategies)
 * we needed to implemented.
 */
public interface AutoMoves {

  /**
   * Method to choose the best move given the specifications of what to look for.
   * @param model of the current game.
   * @return a TriosMove, which is where to place card and from what index in the hand.
   */
  TriosMove chooseMove(ReadonlyThreeTriosModel model);

}
