package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Mock of the model that creates a transcript of where placeCard is put.
 * Allows us to test strategies to ensure they are working correctly.
 */
public class ModelMockTranscripted extends TriosModel implements IModel {
  TriosModel triosModel;
  //public for testing
  public List<String> listOfCords;
  public List<String> listOfCordsReadable;
  public List<String> listOfPlaced;
  private int count = 0;

  /**
   * constructor for the mock that takes in a TriosModel.
   *
   * @param triosModel of a real game model.
   */
  public ModelMockTranscripted(TriosModel triosModel) {
    this.triosModel = triosModel;
    listOfCords = new ArrayList<>();
    listOfPlaced = new ArrayList<>();
    listOfCordsReadable = new ArrayList<>();
  }


  @Override
  public void startGame(Board board, List<GameCard> deck) {
    triosModel.startGame(board, deck);
  }

  @Override
  public void battle(int row, int col) {
    triosModel.battle(row, col);
  }

  @Override
  public void placeCard(int row, int col, int cardPosition) {
    if (count % 2 == 0) {
      listOfPlaced.add(String.valueOf(row) + String.valueOf(col));
    }
    triosModel.placeCard(row, col, cardPosition);
    count++;
  }

  @Override
  public Card getCardAt(int row, int col) {
    return triosModel.getCardAt(row, col);
  }

  @Override
  public boolean isGameWon() {
    return triosModel.isGameWon();
  }

  @Override
  public int getWinner() {
    return triosModel.getWinner();
  }

  @Override
  public int playersTurn() {
    return triosModel.playersTurn();
  }

  @Override
  public int numRows() {
    return triosModel.numRows();
  }

  @Override
  public int numCols() {
    return triosModel.numCols();
  }

  @Override
  public List<GameCard> getCurPlayerHand() {
    return triosModel.getCurPlayerHand();
  }

  @Override
  public Card getCardCopyAt(int row, int col) {
    return triosModel.getCardCopyAt(row, col);
  }

  @Override
  public int ownerOfCard(int row, int col) {
    return triosModel.ownerOfCard(row, col);
  }

  @Override
  public int getScore(int player) {
    return triosModel.getScore(player);
  }

  @Override
  public int getGridSize() {
    return triosModel.getGridSize();
  }

  @Override
  public int getGridUsableSize() {
    return triosModel.getGridUsableSize();
  }

  @Override
  public boolean legalMove(int row, int col) {
    return triosModel.legalMove(row, col);
  }

  @Override
  public int countCardsFlipped(int row, int col, GameCard card) {
    listOfCords.add(String.valueOf(row) + String.valueOf(col));
    listOfCordsReadable.add("row: " + String.valueOf(row) + " column: " + String.valueOf(col));
    return triosModel.countCardsFlipped(row, col, card);
  }

  @Override
  public List<GameCard> getHand(int player) {
    return triosModel.getHand(player);
  }

  @Override
  public Board getBoard() {
    return triosModel.getBoard();
  }

  @Override
  public int addIfFlipped(int row, int col, int altRow, int altCol, int toPlayCard, int altIndex) {
    listOfPlaced.add(String.valueOf(row) + String.valueOf(col));
    return triosModel.addIfFlipped(row, col, altRow, altCol, toPlayCard, altIndex);
  }

}
