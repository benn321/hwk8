package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents a Board, which is a grid (2D list) of cards. The board can contain cards,
 * blocked cells, or empty (null) cells, providing the foundation for a card-based game.
 */
public class Board {
  private List<List<Card>> board = new ArrayList<>();

  /**
   * Default constructor that initializes an empty board.
   */
  public Board() {
    this.board = new ArrayList<>();
  }

  /**
   * Constructor that takes in a board and makes a copy of it.
   * Used for when making a copy of the model for countFlippedCards().
   *
   * @param board that needs to be copied.
   */
  public Board(Board board) {
    List<List<Card>> boardCopy = new ArrayList<>();
    BlockedCell blockedCellToAdd = new BlockedCell();
    for (int row = 0; board.boardRowSize() > row; row++) {
      ArrayList<Card> rowToAdd = new ArrayList<>();
      for (int col = 0; board.boardColSize() > col; col++) {
        if (board.getTile(row, col) instanceof GameCard) {
          GameCard cardToAdd = new GameCard((GameCard) board.getTile(row, col));
          rowToAdd.add(cardToAdd);
        } else if (board.getTile(row, col) instanceof BlockedCell) {
          rowToAdd.add(blockedCellToAdd);
        } else {
          rowToAdd.add(null);
        }
      }
      boardCopy.add(rowToAdd);
    }
    this.board = boardCopy;
  }

  /**
   * Constructs a Board with specified dimensions and a specified number of blocked cells.
   * Randomly places blocked cells on the board, using a provided Random instance.
   *
   * @param row        the number of rows in the board
   * @param col        the number of columns in the board
   * @param numBlocked the number of cells to block
   * @param rand       a Random instance for determining blocked cell locations
   */
  public Board(int row, int col, int numBlocked, Random rand) {
    for (int rowNum = 0; rowNum < row; rowNum++) {
      List<Card> rowList = new ArrayList<>();
      for (int colNum = 0; colNum < col; colNum++) {
        rowList.add(null);
      }
      board.add(rowList);
    }

    for (int cellsToBlock = numBlocked; cellsToBlock > 0; cellsToBlock--) {
      int rowIndex = rand.nextInt(row);
      int colIndex = rand.nextInt(col);
      if (board.get(rowIndex).get(colIndex) == null) {
        board.get(rowIndex).set(colIndex, new BlockedCell());
      } else {
        cellsToBlock++; // Retry if cell is already blocked
      }
    }
  }

  /**
   * Constructs a Board using an existing 2D list of cards.
   *
   * @param board a 2D list representing the board's layout
   */
  public Board(List<List<Card>> board) {
    this.board = board;
  }

  /**
   * Counts the number of empty (null) cells on the board.
   *
   * @return the count of null cells on the board
   */
  public int countNulls() {
    int nullCount = 0;
    for (int row = 0; row < board.size(); row++) {
      for (int col = 0; col < board.get(row).size(); col++) {
        if (board.get(row).get(col) == null) {
          nullCount++;
        }
      }
    }
    return nullCount;
  }

  /**
   * Counts the cards owned by each player on the board and returns the winner based on who
   * owns more cards. This should be used only when the game is over.
   *
   * @return 1 if player one has more cards, 2 if player two has more cards, or 0 if tied
   */
  public int counterPlayerCards(int owner) {
    int cardCount = 0;
    for (int row = 0; row < board.size(); row++) {
      for (int col = 0; col < board.get(row).size(); col++) {
        if (board.get(row).get(col) != null) {
          if (board.get(row).get(col).getOwner() == owner) {
            cardCount++;
          }
        }
      }
    }
    return cardCount;
  }

  /**
   * Retrieves the card at the specified row and column.
   *
   * @param row the row index of the card
   * @param col the column index of the card
   * @return the Card at the specified position, or null if the cell is empty
   * @throws IllegalArgumentException if row or column are out of bounds
   */
  protected Card getTile(int row, int col) {
    checkBounds(row, col);
    return board.get(row).get(col);
  }

  /**
   * Returns the number of columns in the board.
   *
   * @return the number of columns
   */
  public int boardColSize() {
    return board.isEmpty() ? 0 : board.get(0).size();
  }

  /**
   * Returns the number of rows in the board.
   *
   * @return the number of rows
   */
  public int boardRowSize() {
    return board.size();
  }

  /**
   * Sets a card at a specific position on the board.
   *
   * @param row  the row index where the card will be placed
   * @param col  the column index where the card will be placed
   * @param card the Card to place at the specified position
   */
  public void set(int row, int col, Card card) {
    checkBounds(row, col);
    board.get(row).set(col, card);
  }

  /**
   * Returns a string representation of the board, showing each row.
   *
   * @return a string representation of the board
   */
  public String toString() {
    StringBuilder forTesting = new StringBuilder();
    for (List<Card> row : board) {
      forTesting.append(row.toString()).append("\n");
    }
    return forTesting.toString();
  }

  /**
   * Checks if the specified row and column are within the bounds of the board.
   *
   * @param row the row index to check
   * @param col the column index to check
   * @throws IllegalArgumentException if row or column are out of bounds
   */
  private void checkBounds(int row, int col) {
    if (row < 0 || row >= board.size() || col < 0 || col >= board.get(row).size()) {
      throw new IllegalArgumentException("row or col out of bounds");
    }
  }
}
