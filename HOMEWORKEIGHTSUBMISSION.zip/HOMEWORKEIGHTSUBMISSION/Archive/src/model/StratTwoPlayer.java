package model;

import view.TriosFeatures;

/**
 * strategy two player implementation to play the game in full.
 */
public class StratTwoPlayer implements Player {
  private TriosFeatures features;
  private ReadonlyThreeTriosModel model;
  private int player;

  /**
   * contructor for the player2 strategy.
   *
   * @param model  the model the player is using.
   * @param player the player number.
   */
  public StratTwoPlayer(ReadonlyThreeTriosModel model, int player) {
    this.model = model;
    this.player = player;
  }

  @Override
  public void setFeatures(TriosFeatures features) {
    this.features = features;
  }

  @Override
  public void makeAMove() {
    AutoMoves bestMove = new GoForCorners();
    TriosMove move = bestMove.chooseMove(model);
    System.out.println(move.toString());
    features.selectCard(move.handPos, player);
    features.placeCard(move.row, move.col);
  }

  @Override
  public int getNum() {
    return this.player;
  }

}
