package model;

/**
 * represents a blockedCell where no card can be placed on the Board.
 */
public class BlockedCell implements Card {
  @Override
  public int getOwner() {
    return 0;
  }

  @Override
  public String toString() {
    return " ";
  }

  @Override
  public Values getWest() {
    return Values.ONE;
  }

  @Override
  public Values getEast() {
    return null;
  }

  @Override
  public Values getNorth() {
    return null;
  }

  @Override
  public Values getSouth() {
    return null;
  }
}
