package model;

import java.util.List;

/**
 * Model that is Read Only, and thus does not have any mutable qualities.
 */
public interface ReadonlyThreeTriosModel {

  /**
   * Checks if the game has been won. The game is considered won if it is over and a player
   * has met the win conditions.
   *
   * @return true if the game is won, false otherwise.
   */
  boolean isGameWon();

  /**
   * Determines the winner of the game based on the count of cards each player owns on the
   * board.
   *
   * @return 1 or 2 indicating the player who won, or 0 if no winner exists.
   * @throws IllegalStateException if the game is not over.
   */
  int getWinner();

  /**
   * Returns the current player's turn.
   *
   * @return 1 if it is player one's turn, or 2 if it is player two's turn.
   */
  int playersTurn();

  /**
   * Retrieves the number of rows in the board.
   *
   * @return the number of rows on the board as an integer.
   */
  int numRows();

  /**
   * Retrieves the number of columns in the board.
   *
   * @return the number of columns on the board as an integer.
   */
  int numCols();

  /**
   * Retrieves the current player's hand, which is a list of cards that can be played.
   * Returns a copy of the hand, not the actual.
   * @return a List of Card objects representing the current player's hand.
   */
  List<GameCard> getCurPlayerHand();

  /**
   * Returns a copy of the card at given row and col.
   * Does not allow for mutation of the actual card in that location.
   * @param row row in grid.
   * @param col col in grid.
   * @return
   */
  Card getCardCopyAt(int row, int col);

  /**
   * gives owner of card at location.
   * @param row row of the card of interest.
   * @param col col of the card of interest.
   * @return the owner (1 or 2).
   */
  int ownerOfCard(int row, int col);

  /**
   * gets the players count of cards that it owns.
   * @param player the player that is of interest.
   * @return the amount fo cards owned by player.
   */
  int getScore(int player);

  /**
   * Returns the physical size of the grid, that is rows * columns.
   * @return int size of the grid = rows * columns.
   */
  int getGridSize();

  /**
   * Returns size of grid that can be used (ie can have a card placed there, amount of nulls).
   * @return int, countNulls() on this grid.
   */
  int getGridUsableSize();

  /**
   * Boolean if a move is legal.
   * If spot is empty and in bounds.
   * @param row in board.
   * @param col in board.
   * @return true/false depending on row and col inputed.
   */
  boolean legalMove(int row, int col);


  /**
   * simulates playing a card down and returns the amount of cards that are flipped.
   * @param row the row of card being placed.
   * @param col the col of the car being placed.
   * @param card the GameCard that is being placed down.
   * @return the amount of cards flipped if placed at that location.
   */
  int countCardsFlipped(int row, int col, GameCard card);

  /**
   * gets the hand copy of a given player.
   * @param player the players hand that you want.
   * @return a copy of the hand.
   */
  List<GameCard> getHand(int player);

  /**
   * gets a copy of the Board.
   * @return a copy of the board.
   */
  Board getBoard();


  /**
   * Simulates playing a card in the specified spot and alternate
   * stop and returns 1 if main spot is flipped.
   * @param row represents the row number.
   * @param col the col number.
   * @param altRow the altRow number.
   * @param altCol the altCol number.
   * @param toPlayCard the card to play.
   * @param altIndex the alternate index.
   * @return returns one if flipped.
   */
  int addIfFlipped(int row, int col, int altRow, int altCol, int toPlayCard, int altIndex);
}
