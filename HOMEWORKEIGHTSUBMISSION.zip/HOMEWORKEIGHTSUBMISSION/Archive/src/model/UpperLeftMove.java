package model;


/**
 * TieBreaker that does the most upper and most left possible.
 * Also closest to 0 in hand index.
 */
public class UpperLeftMove implements AutoMoves {
  /**
   * chooseMove based on upper left most spot.
   *
   * @param model of the current game.
   * @return
   */
  @Override
  public TriosMove chooseMove(ReadonlyThreeTriosModel model) {
    for (int row = 0; row < model.numRows(); row++) {
      for (int col = 0; col < model.numCols(); col++) {
        if (model.getCardCopyAt(row, col) == null) {
          System.out.println(row + " " + col);
          return new TriosMove(row, col, 0);
        }
      }
    }
    return null;
  }
}
