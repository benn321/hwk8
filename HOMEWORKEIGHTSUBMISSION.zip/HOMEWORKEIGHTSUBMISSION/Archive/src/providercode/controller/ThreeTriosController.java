package providercode.controller;

/**
 * Interface that represents the controller of the game.
 * Contains the moves and what the player needs to do during the game.
 */
public interface ThreeTriosController {

  void selectCard();

  void placeCard();

  void selectCardFile();

  void selectBoardFile();

  void startGame();

  void chooseShuffle();
}
