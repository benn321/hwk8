package providercode.model;

import java.util.Optional;

/**
 * Strategy interface that can allows the possibility of no Move to be returned.
 */
public interface FalliblePlacingStrategy {

  /**
   * Returns an Optional containing the best move according to the strategy.
   *
   * @param model ReadOnly game model to ensure the strategy doesn't change the model
   * @return Optional containing the best move,
   *         or an empty Optional if no more moves are possible (game is over)
   */
  Optional<Move> getMove(ReadOnlyThreeTriosModel model);
}
