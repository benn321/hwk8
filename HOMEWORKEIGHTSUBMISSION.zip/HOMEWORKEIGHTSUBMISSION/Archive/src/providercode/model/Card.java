package providercode.model;

/**
 * Interface that represents the card.
 * This is implemented in playing card to be the 4 directional card with values.
 * Has getter methods to return values of directions, and setter to set color.
 */
public interface Card {

  String toString();

  void setColor(ThreeTriosColor color);

  int getNorth();

  int getSouth();

  int getEast();

  int getWest();

  ThreeTriosColor getColor();

  String getName();
}
