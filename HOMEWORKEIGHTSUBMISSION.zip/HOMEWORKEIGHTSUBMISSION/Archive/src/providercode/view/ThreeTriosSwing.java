package providercode.view;

import providercode.model.Card;
import cs3500.threetrios.model.CellValue;
import providercode.model.ReadOnlyThreeTriosModel;
import cs3500.threetrios.model.ThreeTriosColor;

import cs3500.threetrios.model.ThreeTriosModel;
import cs3500.threetrios.view.swing.Features;
import cs3500.threetrios.view.swing.FeaturesImpl;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Swing-based view for the ThreeTrios game. Creates a GUI view for the ThreeTrios game.
 */
public class ThreeTriosSwing extends JPanel implements Swing {
  private final ReadOnlyThreeTriosModel model;
  private JPanel redPlayerPanel;
  private JPanel bluePlayerPanel;
  private final Features features;
  private final List<PlayerActionListener> actionListeners = new ArrayList<>();
  private JLabel currentPlayerLabel;

  private static final Color RED_COLOR = new Color(255, 50, 50);
  private static final Color BLUE_COLOR = new Color(50, 50, 255);
  private static final Border SELECTED_BORDER = BorderFactory.createLineBorder(Color.GRAY, 3);
  private static final Border NORMAL_BORDER = BorderFactory.createLineBorder(Color.BLACK, 1);

  /**
   * Constructs a ThreeTriosSwing view.
   * @param model the read-only model
   */
  public ThreeTriosSwing(ReadOnlyThreeTriosModel model) {
    this.model = model;
    this.features = new FeaturesImpl(this);
    GameObserver observer = new Observer(this);

    setPreferredSize(new Dimension(800, 700));
    setLayout(new BorderLayout(5, 5));
    setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    initializeComponents();

    if (model instanceof ThreeTriosModel) {
      ((ThreeTriosModel) model).addGameObserver(observer);
    }

  }

  /**
   * Refreshes the view with the updated model.
   */
  public void refreshView() {
    removeAll();
    initializeComponents();
    revalidate();
    repaint();
  }


  /**
   * Initializes the components of the view.
   */
  public void initializeComponents() {
    initCurrentPlayerLabel();
    initPlayerHands();
    initGridPanel();
  }

  private void initCurrentPlayerLabel() {
    currentPlayerLabel = new JLabel("Current player: " + model.getPlayer(),
            SwingConstants.CENTER);
    currentPlayerLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
    currentPlayerLabel.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
    add(currentPlayerLabel, BorderLayout.NORTH);
  }

  /**
   * Updates the current player label -- used when it was a single window view.
   */
  public void updateCurrentPlayerLabel() {
    if (currentPlayerLabel != null) {
      currentPlayerLabel.setText("Current player: " + model.getPlayer());
    }
  }


  private void initPlayerHands() {
    redPlayerPanel = createPlayerHandPanel(model.getRedPlayerHand(), true);
    add(redPlayerPanel, BorderLayout.WEST);

    bluePlayerPanel = createPlayerHandPanel(model.getBluePlayerHand(), false);
    add(bluePlayerPanel, BorderLayout.EAST);
  }

  private JPanel createPlayerHandPanel(List<Card> hand, boolean isRed) {
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    panel.setPreferredSize(new Dimension(80, 0));
    panel.setBackground(isRed ? RED_COLOR : BLUE_COLOR);
    panel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));

    for (int i = 0; i < hand.size(); i++) {
      JPanel cardPanel = createCard(hand.get(i), isRed, i);
      panel.add(cardPanel);
      panel.add(Box.createVerticalStrut(3));
    }

    return panel;
  }

  private JLabel createValueLabel(int value) {
    JLabel label = new JLabel(String.valueOf(value), SwingConstants.CENTER);
    label.setForeground(Color.WHITE);
    label.setFont(new Font("Times New Roman", Font.BOLD, 18));
    return label;
  }

  private void initGridPanel() {
    JPanel gridPanel = new JPanel();
    int numRows = model.getNumOfRows();
    int numCols = model.getNumOfColumns();
    gridPanel.setLayout(new GridLayout(numRows, numCols, 2, 2));
    gridPanel.setBackground(Color.DARK_GRAY);

    for (int row = 0; row < numRows; row++) {
      for (int col = 0; col < numCols; col++) {
        JPanel cellPanel = createCellPanel(row, col);
        gridPanel.add(cellPanel);
      }
    }
    JPanel centerWrapper = new JPanel(new BorderLayout());
    centerWrapper.setBackground(Color.LIGHT_GRAY);
    centerWrapper.add(gridPanel, BorderLayout.CENTER);
    add(centerWrapper, BorderLayout.CENTER);
  }

  private JPanel createCellPanel(final int row, final int col) {
    JPanel cellPanel = new JPanel(new BorderLayout());
    CellValue cellValue = model.getCell(row, col);
    updateCell(cellPanel, cellValue, row, col);
    cellPanel.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        features.gridCellClicked(row, col);
      }
    });

    return cellPanel;
  }

  private void updateCell(JPanel cellPanel, CellValue cellValue, int row, int col) {
    if (cellValue == CellValue.HASCARD) {
      Card card = model.getBoard()[row][col].getCard();
      ThreeTriosColor color = card.getColor();
      JPanel cardPanel = createCard(card, color == ThreeTriosColor.RED, -1);
      cellPanel.add(cardPanel, BorderLayout.CENTER);
      cellPanel.setBackground(Color.YELLOW);
    } else if (cellValue == CellValue.HOLE) {
      cellPanel.setBackground(Color.DARK_GRAY);
    } else {
      cellPanel.setBackground(Color.YELLOW);
    }
  }

  private JPanel createCard(Card card, boolean isRed, final int index) {
    JPanel cardPanel = new JPanel(new GridLayout(3, 3));
    cardPanel.setBackground(isRed ? RED_COLOR : BLUE_COLOR);
    cardPanel.setBorder(NORMAL_BORDER);
    //top
    cardPanel.add(new JLabel(""));
    cardPanel.add(createValueLabel(card.getNorth()));
    cardPanel.add(new JLabel(""));


    //middle
    cardPanel.add(createValueLabel(card.getWest())); // left
    cardPanel.add(new JLabel(""));
    cardPanel.add(createValueLabel(card.getEast())); //right

    //bottom
    cardPanel.add(new JLabel(""));
    cardPanel.add(createValueLabel(card.getSouth())); //middle
    cardPanel.add(new JLabel(""));

    cardPanel.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        features.cardClicked(isRed, index);
      }
    });

    return cardPanel;
  }

  /**
   * Updates the selection state of a card.
   */
  public void updateSelectedCard(boolean isRed, int index, boolean selected) {
    JPanel handPanel = isRed ? redPlayerPanel : bluePlayerPanel;
    Component[] components = handPanel.getComponents();

    for (Component comp : components) {
      if (comp instanceof JPanel) {
        ((JPanel) comp).setBorder(NORMAL_BORDER);
      }
    }

    if (selected && index >= 0 && index * 2 < components.length) {
      Component comp = components[index * 2];
      if (comp instanceof JPanel) {
        ((JPanel) comp).setBorder(SELECTED_BORDER);
      }
    }
  }

  /**
   * Adds the player action listener to the view to keep track of the human player's selections.
   * @param listener action listeners
   */
  public void addPlayerActionListener(PlayerActionListener listener) {
    actionListeners.add(listener);
  }

  /**
   * Notifies the listeners when a card is selected.
   * @param cardIndex index of selected card
   */
  public void notifyCardSelected(int cardIndex) {
    for (PlayerActionListener listener : actionListeners) {
      listener.onCardSelected(cardIndex);
    }
  }

  /**
   * Notifies the listeners when a cell is selected.
   * @param row row index of selected cell
   * @param col col index of selected cell
   */
  public void notifyCellSelected(int row, int col) {
    for (PlayerActionListener listener : actionListeners) {
      listener.onCellSelected(row, col);
    }
  }
}

