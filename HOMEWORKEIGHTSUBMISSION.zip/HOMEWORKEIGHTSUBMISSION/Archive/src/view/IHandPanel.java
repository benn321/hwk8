package view;

/**
 * interface to repreent a hand panel.
 */
public interface IHandPanel {

  /**
   * sets the features, that are yet to implemented.
   *
   * @param features that user can do, and connect controller and view.
   */
  void setFeatures(TriosFeatures features);

  /**
   * refreshes the Hand Panel.
   */
  void refresh();
}
