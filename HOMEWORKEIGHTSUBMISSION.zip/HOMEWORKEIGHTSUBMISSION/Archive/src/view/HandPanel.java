package view;

import javax.swing.JPanel;
import javax.swing.BoxLayout;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.awt.BasicStroke;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;

import model.ReadonlyThreeTriosModel;

/**
 * Panel representing a hand in the game. Both player 1 and 2 hands use this.
 * they just create two different objects of this type.
 */
public class HandPanel extends JPanel implements IHandPanel {
  ReadonlyThreeTriosModel model;
  private TriosFeatures features;
  private final int owner;
  private int cellWidth;
  private int cellHeight;
  private int selectedCell;

  /**
   * constructor for HandPanel that takes in a model and the owner/player.
   *
   * @param model of the game played.
   * @param owner player 1 or 2.
   */
  public HandPanel(ReadonlyThreeTriosModel model, int owner) {
    this.model = model;
    this.owner = owner;
    this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
    this.selectedCell = -1;

    // Add a mouse listener for detecting clicks on cells
    addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        refresh();
        handleCellClick(e);
      }
    });

  }

  /**
   * method for handling cell clicks.
   *
   * @param e mouseevent, a click.
   */
  private void handleCellClick(MouseEvent e) {
    int col = e.getX() / cellWidth;
    int row = e.getY() / cellHeight;

    // Check if the clicked cell is within bounds
    if (row >= 0 && row < model.getHand(owner).size() && col == 0) {
      // Pass the cell position to the features interface
      selectedCell = features.selectCard(row, owner);
      System.out.println("player " + owner + " index " + row);
    }

  }

  /**
   * paints the component.
   *
   * @param g the <code>Graphics</code> object to protect
   */
  protected void paintComponent(Graphics g) {
    cellWidth = this.getWidth();
    if (model.getHand(owner).size() != 0) {
      cellHeight = this.getHeight() / model.getHand(owner).size();


      super.paintComponents(g);
      Graphics2D g2d = (Graphics2D) g;
      int cellWidth = this.getWidth();
      int cellHeight = this.getHeight() / model.getHand(owner).size();

      for (int cardIndex = 0; cardIndex < model.getHand(owner).size(); cardIndex++) {
        BasicStroke border = new BasicStroke(3);
        if (selectedCell != -1 && selectedCell == cardIndex) {
          border = new BasicStroke(7);
        }
        CellShape cell = new CellShape((double) cellWidth, (double) cellHeight);
        AffineTransform transform = new AffineTransform();
        transform.translate(0, cellHeight * cardIndex);
        if (model.getHand(owner).get(cardIndex).getOwner() == 1) {
          g2d.setColor(Color.RED);
          g2d.fill(transform.createTransformedShape(cell));
          g2d.setColor(Color.DARK_GRAY);
          g2d.setStroke(border);
          g2d.draw(transform.createTransformedShape(cell));


          this.addNumbers(g2d, cardIndex);
        }
        if (model.getHand(owner).get(cardIndex).getOwner() == 2) {
          g2d.setColor(Color.CYAN);
          g2d.fill(transform.createTransformedShape(cell));
          g2d.setColor(Color.DARK_GRAY);
          g2d.setStroke(border);
          g2d.draw(transform.createTransformedShape(cell));

          this.addNumbers(g2d, cardIndex);
        }
      }
    } else {
      Graphics2D g2d = (Graphics2D) g;
      int cellWidth = this.getWidth();
      int cellHeight = this.getHeight();
      CellShape cell = new CellShape((double) cellWidth, (double) cellHeight);
      g2d.setColor(Color.DARK_GRAY);
      AffineTransform transform = new AffineTransform();
      g2d.fill(transform.createTransformedShape(cell));
    }
  }

  /**
   * Method for adding numbers to the cards drawn.
   *
   * @param g2d       graphics.
   * @param cardIndex card index.
   */
  private void addNumbers(Graphics2D g2d, int cardIndex) {
    int cellWidth = this.getWidth();
    int cellHeight = this.getHeight() / model.getHand(owner).size();

    g2d.setFont(new Font("SansSerif", Font.BOLD, (cellWidth + cellHeight) / 10));
    g2d.setColor(Color.BLACK);

    int x = (cellWidth / 6);
    int y = (cardIndex * cellHeight + (cellHeight / 2));
    g2d.drawString(String.valueOf(model.getHand(owner).get(cardIndex).getWest()), x, y);

    x = (cellWidth / 6) * 5;
    y = (cardIndex * cellHeight + (cellHeight / 2));
    g2d.drawString(String.valueOf(model.getHand(owner).get(cardIndex).getEast()), x, y);

    x = (cellWidth / 2);
    y = (cardIndex * cellHeight + (cellHeight / 6));
    g2d.drawString(String.valueOf(model.getHand(owner).get(cardIndex).getNorth()), x, y);

    x = (cellWidth / 2);
    y = (cardIndex * cellHeight + ((cellHeight / 6) * 5));
    g2d.drawString(String.valueOf(model.getHand(owner).get(cardIndex).getSouth()), x, y);
  }


  /**
   * sets the features, that are yet to implemented.
   *
   * @param features that user can do, and connect controller and view.
   */
  @Override
  public void setFeatures(TriosFeatures features) {
    this.features = features;
  }


  /**
   * repaints panel.
   */
  public void refresh() {
    this.revalidate();
    this.repaint();
  }


}