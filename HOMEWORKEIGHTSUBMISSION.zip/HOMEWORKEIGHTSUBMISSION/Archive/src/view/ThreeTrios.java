package view;

import java.io.FileNotFoundException;
import java.util.List;

import controller.CardDataBaseReader;
import controller.GridReader;
import controller.TriosController;
import model.Board;
import model.GameCard;
import model.HumanPlayer;
import model.Player;
import model.StratOnePlayer;
import model.StratTwoPlayer;
import model.TriosModel;

/**
 * class to run the game using command line inputs.
 * "human" makes a human player.
 * "strategy1" makes a strategy 1 ai player.
 * "strategu2" makes a strategy 2 ai player.
 * if using jar file to run, input the commands when calling the jar file in the terminal
 */
public class ThreeTrios {


  /**
   * main method where the game is ran and user can input directions to start the game.
   */
  public static void main(String[] args) throws FileNotFoundException {
    List<GameCard> deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    Board board5by7 = new GridReader("ConfigurationFiles/3x3NoHoles").gridBuilder();
    TriosModel model = new TriosModel();
    model.startGame(board5by7, deck);
    TriosGraphicsFrame viewPlayer1 = new TriosGraphicsFrame(model);
    TriosGraphicsFrame viewPlayer2 = new TriosGraphicsFrame(model);
    // Parse command line arguments
    if (args.length < 2) {
      throw new IllegalArgumentException("not enough input.");
    }


    String first = args[0];
    String second = args[1];
    Player playerOneCommand;
    Player playerTwoCommand;

    if (first.equals("human")) {
      playerOneCommand = new HumanPlayer(model, 1);
    } else if (first.equals("strategy1")) {
      playerOneCommand = new StratOnePlayer(model, 1);
    } else if (first.equals("strategy2")) {
      playerOneCommand = new StratTwoPlayer(model, 1);
    } else {
      throw new IllegalArgumentException("incorrect input");
    }

    if (second.equals("human")) {
      playerTwoCommand = new HumanPlayer(model, 2);
    } else if (second.equals("strategy1")) {
      playerTwoCommand = new StratOnePlayer(model, 2);
    } else if (second.equals("strategy2")) {
      playerTwoCommand = new StratTwoPlayer(model, 2);
    } else {
      throw new IllegalArgumentException("incorrect input");
    }

    TriosController controller1 = new TriosController(model, viewPlayer1, playerOneCommand);
    TriosController controller2 = new TriosController(model, viewPlayer2, playerTwoCommand);
    TriosGraphicsFrame view = new TriosGraphicsFrame(model);


  }
}
