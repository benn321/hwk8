package view;


import javax.swing.JPanel;


import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.BasicStroke;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;

import model.BlockedCell;
import model.Card;
import model.GameCard;
import model.ReadonlyThreeTriosModel;

/**
 * Panel representing just the Board (grid) in the game.
 */
public class BoardPanel extends JPanel implements IBoardPanel {
  ReadonlyThreeTriosModel model;
  private TriosFeatures features;
  int cellWidth;
  int cellHeight;

  /**
   * constructor that takes in a model and begins set up.
   * Also adds a mouseListener for detecting clicks on cells.
   *
   * @param model of game in play.
   */
  public BoardPanel(ReadonlyThreeTriosModel model) {
    this.model = model;
    this.setLayout(new GridLayout(model.numRows(), model.numCols()));
    cellWidth = this.getWidth() / model.numCols();
    cellHeight = this.getHeight() / model.numRows();


    // Add a mouse listener for detecting clicks on cells
    addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        refresh();
        handleCellClick(e);
      }
    });
  }

  /**
   * Method for handling cell click.
   *
   * @param e MouseEvent, a click.
   */
  private void handleCellClick(MouseEvent e) {
    cellWidth = this.getWidth() / model.numCols();
    cellHeight = this.getHeight() / model.numRows();

    int col = e.getX() / cellWidth;
    int row = e.getY() / cellHeight;

    // Check if the clicked cell is within bounds
    if (row >= 0 && row < model.numRows() && col >= 0 && col < model.numCols()) {
      features.placeCard(row, col);
      System.out.println("cell at row " + row + " col " + col);
    }
  }


  /**
   * paints the component.
   *
   * @param g the <code>Graphics</code> object to protect
   */
  protected void paintComponent(Graphics g) {
    super.paintComponents(g);
    Graphics2D g2d = (Graphics2D) g;
    int cellWidth = this.getWidth() / model.numCols();
    int cellHeight = this.getHeight() / model.numRows();
    BasicStroke border = new BasicStroke(3);
    for (int rows = 0; rows < model.numRows(); rows++) {
      for (int cols = 0; cols < model.numCols(); cols++) {
        CellShape cell = new CellShape((double) cellWidth, (double) cellHeight);

        AffineTransform transform = new AffineTransform();
        transform.translate(cellWidth * cols, cellHeight * rows);

        if (model.getCardCopyAt(rows, cols) == null) {
          g2d.setColor(Color.YELLOW);
          g2d.fill(transform.createTransformedShape(cell));

          g2d.setColor(Color.DARK_GRAY);
          g2d.setStroke(border);
          g2d.draw(transform.createTransformedShape(cell));
        }
        if (model.getCardCopyAt(rows, cols) instanceof BlockedCell) {
          g2d.setColor(Color.GRAY);
          g2d.fill(transform.createTransformedShape(cell));
          g2d.setColor(Color.DARK_GRAY);
          g2d.setStroke(border);
          g2d.draw(transform.createTransformedShape(cell));
        }
        if (model.getCardCopyAt(rows, cols) instanceof GameCard) {
          if (model.getCardCopyAt(rows, cols).getOwner() == 1) {
            g2d.setColor(Color.RED);
            g2d.fill(transform.createTransformedShape(cell));
            g2d.setColor(Color.DARK_GRAY);
            g2d.setStroke(border);
            g2d.draw(transform.createTransformedShape(cell));
            addNumbers(g2d, rows, cols);
          }
          if (model.getCardCopyAt(rows, cols).getOwner() == 2) {
            g2d.setColor(Color.CYAN);
            g2d.fill(transform.createTransformedShape(cell));
            g2d.setColor(Color.DARK_GRAY);
            g2d.setStroke(border);
            g2d.draw(transform.createTransformedShape(cell));
            addNumbers(g2d, rows, cols);
          }
        }
      }
    }

  }

  /**
   * adds numbers to the cards drawn.
   *
   * @param g2d Graphics2D to allow for the drawing.
   * @param row in grid/board.
   * @param col in grid/board.
   */
  private void addNumbers(Graphics2D g2d, int row, int col) {
    int cellWidth = this.getWidth() / model.numCols();
    int cellHeight = this.getHeight() / model.numRows();
    Card card = model.getCardCopyAt(row, col);


    // this makes the font size dependent on the size of the cells it is on
    g2d.setFont(new Font("SansSerif", Font.BOLD, (cellWidth + cellHeight) / 10));
    g2d.setColor(Color.BLACK);

    int x = col * cellWidth + (cellWidth / 6);
    int y = row * cellHeight + (cellHeight / 2);
    g2d.drawString(String.valueOf(card.getWest()), x, y);

    x = col * cellWidth + ((cellWidth / 6) * 5);
    y = (row * cellHeight + (cellHeight / 2));
    g2d.drawString(String.valueOf(card.getEast()), x, y);

    x = col * cellWidth + (cellWidth / 2);
    y = (row * cellHeight + (cellHeight / 6));
    g2d.drawString(String.valueOf(card.getNorth()), x, y);

    x = col * cellWidth + (cellWidth / 2);
    y = (row * cellHeight + ((cellHeight / 6) * 5));
    g2d.drawString(String.valueOf(card.getSouth()), x, y);
  }

  /**
   * sets the features, that are yet to implemented.
   *
   * @param features that user can do, and connect controller and view.
   */
  @Override
  public void setFeatures(TriosFeatures features) {
    this.features = features;
  }


  /**
   * repaints panel.
   */
  public void refresh() {
    this.revalidate();
    this.repaint();
  }

}

