package view;

import java.io.FileNotFoundException;
import java.util.List;

import controller.TriosController;
import model.Board;
import controller.CardDataBaseReader;
import model.GameCard;
import controller.GridReader;
import model.HumanPlayer;
import model.Player;
import model.StratOnePlayer;
import model.StratTwoPlayer;
import model.TriosModel;

/**
 * class test visually tests the view.
 */
public final class ThreeTriosManualInput {

  /**
   * main method to test the view.
   * @param args the args passed in.
   * @throws FileNotFoundException if file is not found.
   */
  public static void main(String[] args) throws FileNotFoundException {

    List<GameCard> deck = new CardDataBaseReader("ConfigurationFiles/CardFile").deckBuilder();
    Board board5by7 = new GridReader("ConfigurationFiles/3x3NoHoles").gridBuilder();
    TriosModel model = new TriosModel();
    model.startGame(board5by7, deck);
    TriosGraphicsFrame viewPlayer1 = new TriosGraphicsFrame(model);
    TriosGraphicsFrame viewPlayer2 = new TriosGraphicsFrame(model);
    Player human1 = new HumanPlayer(model, 1);
    Player human2 = new HumanPlayer(model, 2);
    Player player1 = new StratOnePlayer(model, 1);
    Player playerStrat1 = new StratOnePlayer(model, 2);
    Player player2 = new StratTwoPlayer(model, 1);
    Player player22 = new StratTwoPlayer(model, 2);
    TriosController controller1 = new TriosController(model, viewPlayer1, player2);
    TriosController controller2 = new TriosController(model, viewPlayer2, player22);
    TriosGraphicsFrame view = new TriosGraphicsFrame(model);
  }
}

