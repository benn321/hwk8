package view;

import java.awt.geom.Path2D;

/**
 * way to draw a cell shape taht makes it easier to draw hands and the board.
 */
public class CellShape extends Path2D.Double {
  double width;
  double height;

  /**
   * constructor for cell shape that draws the cell.
   *
   * @param width  of cell to be drawn.
   * @param height of cell to be drawn.
   */
  public CellShape(double width, double height) {
    moveTo(0, 0);
    lineTo(width, 0);
    lineTo(width, height);
    lineTo(0, height);
    closePath();


  }


}
