package view;

import java.io.IOException;

import model.IModel;

/**
 * A text-based view for the Trio game that renders the current game state as a formatted string.
 * Displays information about the player's turn, the board, and the current player's hand.
 */
public class TrioStringView implements SimpleStringView {
  private final IModel model;
  private Appendable ap;

  /**
   * Constructs a {@code TrioStringView} with a model and initializes the output with a
   * {@code StringBuilder}.
   *
   * @param model the game model to display
   * @throws IllegalArgumentException if the model is {@code null}
   */
  public TrioStringView(IModel model) {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    this.model = model;
    this.ap = new StringBuilder();
  }

  /**
   * Constructs a {@code TrioStringView} with a model and a specified {@code Appendable}
   * output destination.
   *
   * @param model the game model to display
   * @param ap    the output destination for the rendered view
   * @throws IllegalArgumentException if the model or appendable is {@code null}
   */
  public TrioStringView(IModel model, Appendable ap) {
    if (model == null || ap == null) {
      throw new IllegalArgumentException("Model or Appendable cannot be null");
    }
    this.model = model;
    this.ap = ap;
  }

  /**
   * Converts the model to a well-formatted string representation, including the player's
   * turn, the board layout, and the current player's hand.
   *
   * @return a formatted string of the game state
   */
  @Override
  public String toString() {
    StringBuilder output = new StringBuilder("Player: ");

    // Indicate the current player's turn
    if (model.playersTurn() == 1) {
      output.append("Red\n");
    } else {
      output.append("Blue\n");
    }

    // Build the board representation
    for (int row = 0; row < model.numRows(); row++) {
      for (int col = 0; col < model.numCols(); col++) {
        if (model.getCardAt(row, col) == null) {
          output.append("_"); // Empty cell
        } else if (model.getCardAt(row, col).getOwner() == 1) {
          output.append("R"); // Player 1's card
        } else if (model.getCardAt(row, col).getOwner() == 2) {
          output.append("B"); // Player 2's card
        } else {
          output.append(model.getCardAt(row, col).toString()); // Card toString()
        }
      }
      output.append("\n");
    }

    // Display the current player's hand
    output.append("Hand:\n");
    output.append(" ").append(model.getCurPlayerHand().toString());

    // Format the string for a more readable output
    String fin = output.toString().replaceAll(",", "\n");
    fin = fin.replaceAll("]", "");
    fin = fin.replace("[", "");
    fin = fin + "\n";
    return fin;
  }

  /**
   * Renders the view by appending the string representation of the game model to the
   * output destination.
   *
   * @throws IOException if an I/O error occurs
   */
  @Override
  public void render() throws IOException {
    ap.append(toString());
  }
}
